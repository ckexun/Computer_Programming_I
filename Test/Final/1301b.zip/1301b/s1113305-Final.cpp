#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using namespace std;
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    fstream loadM("Members.dat", ios::in | ios::out | ios::binary);
    if (!loadM)
    {
        cerr << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    MemberRecord x;
    loadM.read(reinterpret_cast<char*>(&x), sizeof(MemberRecord));
    while (!loadM.eof())
    {
        memberDetails.push_back(x);
        loadM.read(reinterpret_cast<char*>(&x), sizeof(MemberRecord));
    }
    loadM.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    fstream loadReser("Reservations.dat", ios::in | ios::out | ios::binary);
    if (!loadReser)
    {
        cerr << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }
    Date currentDate = compCurrentDate();
    ReservationRecord  y;
    loadReser.read(reinterpret_cast<char*>(&y), sizeof(ReservationRecord));

    while (!loadReser.eof())
    {   
        if (lessEqual(y.date, currentDate))
        {   
            loadReser.read(reinterpret_cast<char*>(&y), sizeof(ReservationRecord));
            continue;
        }
        reservations.push_back(y);
        loadReser.read(reinterpret_cast<char*>(&y), sizeof(ReservationRecord));
    }
    loadReser.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )//���pture
{
    if (date1.year > date2.year)
        return false;
    else if (date1.year < date2.year)
        return true;
    else if (date1.year == date2.year)
    {
        if (date1.month > date2.month)
            return false;
        else if (date1.month < date2.month)
            return true;
        else if (date1.month == date2.month)
        {
            if (date1.day > date2.day)
                return false;
            else if (date1.day < date2.day)
                return true;
            else if (date1.day == date2.day)
                return false;
        }
    }
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    int ti = memberDetails.size();
    int check = 0;
    int i = 0;
    for ( i ; i < ti; i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
        {
            check++;
            break;
        }
    }
    if (check == 0)
    {
        cout << "\nInvalid account number or password. Please try again.\n\n";
        return false;
    }
    else
    {
        if (strcmp(password, memberDetails[i].password) == 0)
            return true;
        else
        {
            cout << "\nInvalid account number or password. Please try again.\n\n";
            return false;
        }
    }
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
    ReservationRecord newReservation;
    for (int i = 0; i < 12; i++)
    {
        newReservation.idNumber[i] = idNumber[i];
    }
    //branchCode
    for (int i = 1; i <= 18; i++)
    {
        cout << i << ". " << branchNames[i] << endl;
    }
    int numspot;
    do {
        cout << "\nEnter your choice (0 to end):";
        cin >> numspot;
    } while (numspot < 0 || numspot>18);
    if (numspot == 0)
    {
        cin.ignore();
        return;
    }
    newReservation.branchCode = numspot;

    Date currenttime = compCurrentDate();
    cout << "\nThe current hour is " << currenttime.year << '/' << currenttime.month << '/' << currenttime.day 
        <<':' << currenttime.hour << endl;
    //date
    int monhtdays[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
    cout << "\nAvailable days:\n\n";
    Date currenttimechange = compCurrentDate();
    if (currenttime.hour == 23)
    {
        if (currenttimechange.month == 12 && currenttimechange.day == 31)
        {
            currenttimechange.year += 1;
            currenttimechange.month = 1;
            currenttimechange.day = 0;
        }
        if (currenttimechange.day == monhtdays[currenttimechange.month])
        {
            currenttimechange.month += 1;
            currenttimechange.day = 0;
        }
        currenttimechange.day += 1;

        if (currenttime.month == 12 && currenttime.day == 31)
        {
            currenttime.year += 1;
            currenttime.month = 1;
            currenttime.day = 0;
        }
        if (currenttime.day == monhtdays[currenttime.month])
        {
            currenttime.month += 1;
            currenttime.day = 0;
        }
        currenttime.day += 1;

        currenttime.hour = 0;
    }

    for (int n = 1; n <= 7; n++)
    {
        cout << n << ". " << currenttimechange.year << '/' << currenttimechange.month << '/' << currenttimechange.day << endl;
        if (currenttimechange.month == 12 && currenttimechange.day == 31)
        {
            currenttimechange.year += 1;
            currenttimechange.month = 1;
            currenttimechange.day = 0;
        }
        if (currenttimechange.day == monhtdays[currenttimechange.month])
        {
            currenttimechange.month += 1;
            currenttimechange.day = 0;
        }
        currenttimechange.day += 1;
    }
    int numdate;
    do {
        cout << "\nEnter your choice (0 to end):";
        cin >> numdate;
    } while (numdate < 0 || numdate>7);
    if (numdate == 0)
    {
        cin.ignore();
        return;
    }
    for (int n = 1; n < numdate; n++)
    {
        if (currenttime.month == 12 && currenttime.day == 31)
        {
            currenttime.year += 1;
            currenttime.month = 1;
            currenttime.day = 0;
        }
        if (currenttime.day == monhtdays[currenttime.month])
        {
            currenttime.month += 1;
            currenttime.day = 0;
        }
        currenttime.day += 1;
    }
    newReservation.date.year = currenttime.year;
    newReservation.date.month = currenttime.month;
    newReservation.date.day = currenttime.day;
    //hour
    int numhour;
    if (numdate == 1)
    {
        do {
            cout << "\nEnter hour (" << currenttime.hour << "~23):";
            cin >> numhour;
        } while (numhour < currenttime.hour || numhour>23);
    }
    else
    {
        do {
            cout << "\nEnter hour (0~23):";
            cin >> numhour;
        } while (numhour < 0 || currenttime.hour>23);
    }
    newReservation.date.hour = numhour;
    //Customers
    int numcustomer;
    do {
        cout << "\nEnter the number of customers (1~30, 0 to end):";
        cin >> numcustomer;
    } while (numcustomer < 0 || numcustomer>30);
    if (numcustomer == 0)
    {
        cin.ignore();
        return;
    }
    newReservation.numCustomers = numcustomer;

    cin.ignore();

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();


}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   //No reservations!
   int ti = reservations.size();
   int check = 0;
   int saveuserposition[100]{};
   int saveuserindex = 1;
   for (int i = 0 ; i < ti; i++)
   {
       if (strcmp(idNumber, reservations[i].idNumber) == 0)
       {    
           check++;
           saveuserposition[saveuserindex] = i;
           saveuserindex++;
       }

   }
   if (check == 0)
   {
       cout << "No reservations!\n";
       return;
   }
   else
   {   
       cout << endl << setw(29) << "Branch"
           << setw(14) << "Date" << setw(8) << "Hour"
           << setw(19) << "No of Customers" << endl;
       for (int i = 1; i <= check; i++)
       {
           cout << i << ". ";
           output(reservations[saveuserposition[i]]);
       }
   }
   //cancel
   int numcancel;
   do {
       cout << "Choose a reservation to cancel (0: keep all reservations): ";
       cin >> numcancel;
   } while (numcancel < 0 || numcancel > check);
   if (numcancel == 0)
   {
       cin.ignore();
       return;
   }
   reservations[saveuserposition[numcancel]].idNumber[0] = 'd';
   cin.ignore();
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    int ti = memberDetails.size();
    int check = 0;
    for (int i = 0; i < ti; i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            check++;
    }
    if (check == 0)
        return false;
    else
        return true;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream saveM("Members.dat",  ios::out | ios::binary);
    if (!saveM)
    {
        cerr << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    int saveti = memberDetails.size();
    saveM.seekp(ios::beg);
    for (int i = 0; i < saveti; i++)
    {
        saveM.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    saveM.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream saveReser("Reservations.dat",  ios::out | ios::binary);
    if (!saveReser)
    {
        cerr << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    int saveti = reservations.size();
    saveReser.seekp(ios::beg);
    for (int i = 0; i < saveti; i++)
    {
        if (reservations[i].idNumber[0] == 'd')
        {
            continue;
        }
        saveReser.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    saveReser.close();

}