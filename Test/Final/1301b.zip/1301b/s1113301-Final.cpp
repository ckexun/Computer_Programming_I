#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream load("Members.dat", ios::in | ios::binary);
    MemberRecord member;
    memberDetails.resize(0);
    while (!(load.eof())) {
        load.read(reinterpret_cast<char*>(&member), sizeof(MemberRecord));
        memberDetails.push_back(member);
    }
    load.clear();
    load.seekg(0, ios::beg);
    load.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream load("Reservations.dat", ios::in | ios::binary);
    ReservationRecord reservation;
    Date currentDate = compCurrentDate();
    reservations.resize(0);
    while (!(load.eof())) {
        load.read(reinterpret_cast<char*>(&reservation), sizeof(ReservationRecord));
        if (lessEqual(currentDate, reservation.date)) {
            //cout << reservation.date.hour << endl;
            reservations.push_back(reservation);
        }
    }
    if (reservations.size() > 0)
        reservations.resize(reservations.size() - 1);
    //cout << reservations.size();
    load.clear();
    load.seekg(0, ios::beg);
    load.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    //cout << "year" << date1.year << " " << date2.year << endl;
    //cout << "month" << date1.month << " " << date2.month << endl;
    //cout << "day" << date1.day << " " << date2.day << endl;
    //cout << "hour" << date1.hour << " " << date2.hour << endl;
    if (date1.year > date2.year)
        return false;
        
    if (date1.year < date2.year)
        return true;
        
    if (date1.month > date2.month)
        return false;
    if (date1.month < date2.month)
        return true;
    if (date1.day > date2.day)
        return false;
    if (date1.day < date2.day)
        return true;
    if (date1.hour > date2.hour)
        return false;
    if (date1.hour < date2.hour)
        return true;
    return true;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 and strcmp(password, memberDetails[i].password) == 0) {
            return true;
        }
    }
    cout << endl << "Invalid account number or password. Please try again." << endl << endl;
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   int choice_ktv; //KTV�ﶵ(0-18)
   int choice_day; //����ﶵ(0-7)
   int choice_hour; //�ɶ��ﶵ
   int numcustomers; //�q���(0-30)
   for (int i = 1; i < 19; i++){
       cout << i << ". " << branchNames[i] << endl;
   }
   //do {
   //    cout << "Enter your choice (0 to end): ";
   //    cin >> choice_ktv;
   //} while (choice_ktv < 0 or choice_ktv > 18);

   do cout << "\nEnter your choice (0 to end): ";
   while ((choice_ktv = inputAnInteger(0, 18)) == -1);
   cout << endl;

   if (choice_ktv == 0) //���w��
       return;

   Date availableDates[8];
   compAvailableDates(availableDates);
   //do {
   //    cout << "Enter your choice (0 to end): ";
   //    cin >> choice_day;
   //} while (choice_day < 0 or choice_day > 7);

   do cout << "\nEnter your choice (0 to end): ";
   while ((choice_day = inputAnInteger(0, 7)) == -1);
   cout << endl;

   if (choice_day == 0) //���w��
       return;
   int hour = 0;
   if (choice_day == 1 ) { //��ܷ���
       hour = availableDates[1].hour + 1;
   }
   do {
       if (hour == 23)
           cout << "Enter hour (" << hour << "): ";
       else
           cout << "Enter hour (" << hour << "~" << 23 << "): ";
       cin >> choice_hour;
   } while (choice_hour < hour or choice_hour > 23);
   cin.ignore();
   //do {
   //    cout << endl << "Enter the number of customers (1~30, 0 to end): ";
   //    cin >> numcustomers;
   //} while (numcustomers < 0 or numcustomers > 30);

   do cout << "\nEnter the number of customers (1~30, 0 to end): ";
   while ((numcustomers = inputAnInteger(0, 30)) == -1);
   cout << endl;

   if (numcustomers == 0) //���w��
       return;
   
   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   newReservation.branchCode = choice_ktv;
   newReservation.date = availableDates[choice_day];
   newReservation.date.hour = choice_hour;
   newReservation.numCustomers = numcustomers;
   //cout << idNumber << endl;
   strcpy_s(newReservation.idNumber, idNumber);
   //cout << newReservation.idNumber << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";
   reservations.push_back( newReservation );
   //saveReservations(reservations);
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   cout << "The current hour is " << currentDate.year << '/' << currentDate.month << '/' 
       << currentDate.day << " : " << currentDate.hour << endl;

   cout << endl << "Available days: " << endl << endl;

   if (currentDate.hour == 23) {
       currentDate.hour = 0;
       currentDate.day++;
   }

   for (int i = 1; i < 8; i++) {
       availableDates[i] = currentDate;
       cout << i << ". " << currentDate.year << '/' << currentDate.month << '/'
           << currentDate.day << endl;
       currentDate.day++;
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();

   int numBooking = 0;
   int choice_cancel; //�����q���x��
   //cout << reservations.size() << endl;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           if (++numBooking == 1) {
               cout << endl << setw(28) << "Branch"
                   << setw(16) << "Date" << setw(8) << "Hour"
                   << setw(21) << "No of Customers" << endl;
           }
           cout << numBooking << ". ";
           output(reservations[i]);
       }
   }

   if (numBooking == 0) {
       cout << "No reservations!" << endl;
       return;
   }

   do cout << "\nChoose a reservation to cancel(0: keep all reservations) : ";
   while ((choice_cancel = inputAnInteger(0, numBooking)) == -1);
   cout << endl;
   if (choice_cancel == 0) //�������q��
       return;
   numBooking = 0;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(reservations[i].idNumber, idNumber) == 0) {
           numBooking++;
           if (numBooking == choice_cancel) {
               for (int a = i; a < reservations.size()-1; a++) {
                   reservations[a] = reservations[a + 1];
               }
               //cout <<  endl << "resize�e" << reservations.size() << endl;
               reservations.resize(reservations.size() - 1);
               //cout << endl << "resize��" << reservations.size() << endl;
               //saveReservations(reservations);
               break;
           }
       }
   }
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );
   saveMemberDetails(memberDetails);

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream saveMember("Members.dat", ios::out | ios::trunc | ios::binary);

    for (int i = 0; i < memberDetails.size(); i++) {
        saveMember.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }

    saveMember.clear();
    saveMember.seekp(0, ios::beg);
    saveMember.close();

}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    Date currentDate = compCurrentDate();
    ofstream saveReservation("Reservations.dat", ios::out | ios::trunc | ios::binary);
    //cout << "saveSize" << reservations.size() << endl;

    for (int i = 0; i < reservations.size(); i++) {
        
        if (lessEqual(currentDate, reservations[i].date)) {
            //cout << i << endl;
            //cout << reservations[i].date.hour << endl;
            saveReservation.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
        }    
    }

    saveReservation.clear();
    saveReservation.seekp(0, ios::beg);
    saveReservation.close();
}