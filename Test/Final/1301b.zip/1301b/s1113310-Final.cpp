#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);
    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream in("Members.dat", ios::binary);
    if (!in)
        cout << "loadMemberDetails can't use";
    in.seekg(0, ios::end);
    int num = (in.tellg() / sizeof(MemberRecord));
    in.seekg(0, ios::beg);
    MemberRecord tmp;
    for (int i = 0; i < num; i++)
    {
        in.read(reinterpret_cast<char*>(tmp.idNumber), sizeof(MemberRecord));
        memberDetails.push_back(tmp);
    }
    in.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream in("Reservations.dat", ios::binary);
    if (!in)
        cout << "loadReservations can't use";
    in.seekg(0, ios::end);
    int num = (in.tellg() / sizeof(ReservationRecord));
    in.seekg(0, ios::beg);
    Date currentDate = compCurrentDate();
    ReservationRecord tmp;
    for (int i = 0; i < num; i++)
    {
        in.read(reinterpret_cast<char*>(&tmp), sizeof(ReservationRecord));
        if (!lessEqual(tmp.date, currentDate))
        {
            reservations.push_back(tmp);
        }
    }
    in.close();

}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year > date2.year) return false;
    else if (date1.month > date2.month) return false;
    else if (date1.day > date2.day) return false;
    else if (date1.hour > date2.hour) return false;
    else return true;
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    if (!existingID(idNumber, memberDetails))
    {
        cout << endl << "Invalid account number or password. Please try again." << endl;
        return false;
    }
    int num = memberDetails.size();
    for (int i = 0; i < num; i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) != 0)
        {
            cout << endl << "Invalid account number or password. Please try again." << endl;
            return false;
        }
        else if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0)
        {
            return true;
        }
    }
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    strcpy_s(newReservation.idNumber, 12, idNumber);
    int place;
    cout << " 1. Taipei Dunhua South\n"
         << " 2. Taipei Zhongxiao\n"
         << " 3. Taipei Songjiang\n"
         << " 4. Taipei Nanjing\n"
         << " 5. Taipei Linsen\n"
         << " 6. Taipei Zhonghua New\n"
         << " 7. Banqiao Guanqian\n"
         << " 8. Yonghe Lehua\n"
         << " 9. Taoyuan Zhonghua\n"
         << "10. Taoyuan Nankan\n"
         << "11. Zhongli Zhongyang\n"
         << "12. Hsinchu Beida\n"
         << "13. Taichung Ziyou\n"
         << "14. Chiayi Ren'ai\n"
         << "15. Tainan Ximen\n"
         << "16. Kaohsiung Zhonghua New\n"
         << "17. Kaohsiung Jianxing\n"
         << "18. Pingtung Kending\n";
    do {
        cout << "\nEnter your choice(0 to end) : ";
        cin >> place;
    } while (place > 18 || place < 0);
    if (place == 0)
        return;
    newReservation.branchCode = place;

    Date currentDate = compCurrentDate();
    Date availableDates[8];
    compAvailableDates(availableDates);
    cout << "\nAvailable days:\n";
    for (int i = 1; i <= 7; i++)
    {
        cout << i << "." << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }
    int dayChoice;
    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> dayChoice;
    } while (dayChoice < 0 || dayChoice>7);
    if (dayChoice == 0)
        return;
    newReservation.date.year = availableDates[dayChoice].year;
    newReservation.date.month = availableDates[dayChoice].month;
    newReservation.date.day = availableDates[dayChoice].day;
    int hourChoice;
    if(newReservation.date.day== currentDate.day)
    {
        do {
            cout << "\nEnter hour (" << currentDate.hour + 1 << "~23): ";
            cin >> hourChoice;
        } while (hourChoice < currentDate.hour + 1 || hourChoice>23);
    }
    else
    {
        do {
            cout << "\nEnter hour (" << 0 << "~23): ";
            cin >> hourChoice;
        } while (hourChoice < 0 || hourChoice>23);
    }
    newReservation.date.hour = hourChoice;
    int people;
    do {
        cout << "\nEnter the number of customers(1~30, 0 to end) :";
        cin >> people;
    } while (people < 0 || people>30);
    if (people == 0)
        return;
    newReservation.numCustomers = people;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
    cin.ignore();
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
    int monthDays[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    availableDates[1] = currentDate;
    for (int i = 2; i <= 7; i++)
    {
        availableDates[i] = availableDates[i - 1];
        availableDates[i].day += 1;
        if (availableDates[i].day > monthDays[availableDates[i].month])
        {
            availableDates[i].day -= monthDays[availableDates[i].month];
            availableDates[i].month += 1;
        }
        if (availableDates[i].month > 12)
        {
            availableDates[i].month = availableDates[i].month % 12;
            availableDates[i].year += 1;
        }
    }



}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();

    int num = reservations.size();
    vector< ReservationRecord > reservationsWithID;
    int numofreservationsWithID = 0;
    for (int i = 0; i < num; i++)
    {
        if (strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            if(!lessEqual(reservations[i].date, currentDate))
            {
                reservationsWithID.push_back(reservations[i]);
                numofreservationsWithID++;
            }
        }
    }
    if (numofreservationsWithID == 0)
    {
        cout << "No reservations!\n";
        return;
    }
    cout << "                       Branch          Date    Hour    No of Customers\n";
    for (int j = 0; j < numofreservationsWithID; j++)
    {
        cout << j + 1 << ".";
        output(reservationsWithID[j]);
    }
    int chioce;
    do {
        cout << endl << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> chioce;
    } while (chioce > numofreservationsWithID || chioce < 0);

    int order = 1;
    for (int i = 0; i < num; i++)
    {
        if (order == chioce && strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            if (i == num - 1)
            {
                reservations.pop_back();
            }
            else 
            {
                for (int j = i; j < num - 1; j++)
                {
                    reservations[i] = reservations[i + 1];
                    reservations.pop_back();
                }
                break;
            }
        }
        else if (order < chioce && strcmp(idNumber, reservations[i].idNumber) == 0)
        {
            order++;
        }
    }
    cout << endl;
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);
    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    int num = memberDetails.size();
    for (int i = 0; i < num; i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            return true;
    }
    return false;

}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream out("Members.dat", ios::binary);
    int num = memberDetails.size();
    for (int i = 0; i < num; i++)
    {
        out.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    out.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream out("Reservations.dat", ios::binary);
    int num = reservations.size();
    for (int i = 0; i < num; i++)
    {
        out.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    out.close();

}