#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    inFile.seekg(0, ios::end);
    int num = static_cast<int>(inFile.tellg()) / sizeof(MemberRecord);
    inFile.seekg(0, ios::beg);
    for (int i = 0; i < num; i++) {
        MemberRecord save;
        inFile.read(reinterpret_cast<char*>(&save), sizeof(MemberRecord));
        memberDetails.push_back(save);
    }
    inFile.close();
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream inFile("Reservations.dat", ios::in | ios::out | ios::binary);
    inFile.seekg(0, ios::end);
    int a = inFile.tellg();
    int num = static_cast<int>(inFile.tellg()) / sizeof(ReservationRecord);
    inFile.seekg(0, ios::beg);
    for (int i = 0; i < num; i++) {
        ReservationRecord save;
        inFile.read(reinterpret_cast<char*>(&save), sizeof(ReservationRecord));
        Date cur = compCurrentDate();
        if (lessEqual(save.date, cur))
            save.idNumber[0] = '\0';
        reservations.push_back(save);    
    }
    inFile.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year < date2.year)
        return true;
    else if (date1.month < date2.month)
        return true;
    else if (date1.day < date2.day)
        return true;
    else if (date1.hour < date2.hour)
        return true;
    else if (date1.year == date2.year && date1.month == date2.month && date1.day == date2.day && date1.hour == date2.hour)
        return true;
    return false;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if (strlen(string) == 0)
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0)
            return true;
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   for (int i = 0; i < sizeof(idNumber); i++)
       newReservation.idNumber[i] = idNumber[i];

   for (int i = 1; i < 19; i++)
       cout << i << ". " << branchNames[i] << endl;
   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> newReservation.branchCode;
   } while (newReservation.branchCode < 0 || newReservation.branchCode>18);
   cin.ignore();
   if (newReservation.branchCode == 0)
       return;
   Date availableDates[8];
   compAvailableDates(availableDates);
   cout << "\nAvailable days:\n\n";
   for (int i = 1; i < 8; i++) {
       cout << i << ". " << availableDates[i].year;
       cout << "/" << availableDates[i].month << "/";
       cout << availableDates[i].day << endl;
   }
   int choice;
   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> choice;
   } while (choice < 0 || choice>7);
   cin.ignore();
   if (choice == 0)
       return;
   newReservation.date = availableDates[choice];
   int hour;
   do {
       cout << "\nEnter hour (" << availableDates[choice].hour << "~23): ";
       cin >> hour;
   } while (hour < availableDates[choice].hour || hour>23);
   newReservation.date.hour = hour;
   int numCus;
   do {
       cout << "\nEnter the number of customers (1~30, 0 to end): ";
       cin >> numCus;
   } while (numCus < 0 || numCus>30);

   cin.ignore();

   if (numCus == 0)
       return;
   newReservation.numCustomers = numCus;

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   cout << "\nThe current hour is " << currentDate.year << "/";
   cout << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
   if (currentDate.hour == 23)
   {
       availableDates[1].day = currentDate.day + 1;
       availableDates[1].hour=0;
       availableDates[1].month = currentDate.month;
       availableDates[1].year = currentDate.year;
   }
   else
   {
       availableDates[1].day = currentDate.day;
       availableDates[1].hour = currentDate.hour + 1;
       availableDates[1].month = currentDate.month;
       availableDates[1].year = currentDate.year;
   }
   for (int i = 2; i < 8; i++) {
       availableDates[i].day = availableDates[i - 1].day + 1;
       availableDates[i].hour = 0;
       availableDates[i].month = availableDates[i - 1].month;
       availableDates[i].year = availableDates[i - 1].year;
   }
   int days[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
   for (int i = 1; i < 8; i++) {
       if (availableDates[i].day > days[availableDates[i].month])
       {
           availableDates[i].day -= days[availableDates[i].month];
           availableDates[i].month++;
       }
       if (availableDates[i].month > 12) {
           availableDates[i].month -= 12;
           availableDates[i].year++;
       }
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   int size = 0;
   for (int i = 0; i < reservations.size(); i++)
       if (reservations[i].idNumber[0] != '\0')
           size++;
   if (size == 0) {
       cout << "\nNo reservations!\n";
       return;
   }
   Date currentDate = compCurrentDate();
   int tar = 0;
   cout << endl << setw(26) << "Branch"
       << setw(14) << "Date" << setw(8) << "Hour"
       << setw(19) << "No of Customers" << endl;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(idNumber, reservations[i].idNumber) == 0) {
           tar++;
           cout << tar << ".";
           cout << setw(24) << branchNames[reservations[i].branchCode]
               << setw(8) << reservations[i].date.year << '-'
               << setw(2) << setfill('0') << reservations[i].date.month << '-'
               << setw(2) << setfill('0') << reservations[i].date.day
               << setw(8) << setfill(' ') << reservations[i].date.hour
               << setw(19) << reservations[i].numCustomers << endl;
       }
   }
   int choice;
   do{
       cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
       cin >> choice;
   } while (choice<0 || choice>tar);
   cin.ignore();
   if (choice == 0)
       return;
   tar = 0;
   for (int i = 0; i < reservations.size(); i++) {
       if (strcmp(idNumber, reservations[i].idNumber) == 0) {
           tar++;
           if (tar == choice) {
               reservations[i].idNumber[0] = '\0';
               break;
           }
       }
   }
}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            return true;
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outFile("Members.dat", ios::out | ios::binary);
    for (int i = 0; i < memberDetails.size(); i++) {
        MemberRecord save = memberDetails[i];
        outFile.write(reinterpret_cast<char*>(&save), sizeof(MemberRecord));
    }
    outFile.close();
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outFile("Reservations.dat", ios::out | ios::binary);
    for (int i = 0; i < reservations.size(); i++) {
        ReservationRecord save = reservations[i];
        outFile.write(reinterpret_cast<char*>(&save), sizeof(ReservationRecord));
    }
    outFile.close();
}