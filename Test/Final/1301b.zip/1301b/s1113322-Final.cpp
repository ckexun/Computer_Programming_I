#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}
// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    std::fstream member("Members.dat", ios::in | ios::out | ios::binary);
    if(!member)
    {
        std::cerr << "flie could not be opend";
        exit(1);
    }
    member.seekg(0, ios::end);
    int nummember = member.tellg() / sizeof(MemberRecord);
    member.seekg(0, ios::beg);
    MemberRecord tempmember;
    for(int i=1;i<=nummember;i++)
    {
        member.read(reinterpret_cast<char*>(&tempmember), sizeof(MemberRecord));//memberDetails[i]
        memberDetails.push_back(tempmember);
    }
    member.close();   
}
// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations )
{
    std::fstream refile("Reservations.dat", ios::in | ios::out | ios::binary);
    if (!refile)
    {
        std::cerr << "flie could not be opend";
        exit(1);
    }
    refile.seekg(0, ios::end);
    int numrefile = refile.tellg() / sizeof(ReservationRecord);
    refile.seekg(0, ios::beg);
    ReservationRecord tempreservation;
    Date current = compCurrentDate();
    for (int i = 1; i <= numrefile; i++)
    {
        refile.read(reinterpret_cast<char*>(&tempreservation), sizeof(ReservationRecord));//reservations[i]
       // date1 <= date2
        if(!lessEqual(tempreservation.date,current))
        { 
            reservations.push_back(tempreservation);
        }      
    }
    refile.close();
}
// compute the current date
Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );//+24*60*60
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 )
{
    if(date1.year>date2.year)
    {
        return false;
    }
    else if(date1.year < date2.year)
    {
        return true;
    }
    else
    {
        if(date1.month > date2.month)
        {
            return false;
        }
        else if(date1.month < date2.month)
        {
            return true;
        }
        else
        {
            if (date1.day > date2.day)
            {
                return false;
            }
            else if (date1.day< date2.day)
            {
                return true;
            }
            else 
            {
                if (date1.hour > date2.hour)
                {
                    return false;
                }
                else if (date1.hour < date2.hour)
                {
                    return true;
                }
                else
                {
                    return true;
                }
            }
        }
    }
}
// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}
// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();//�P�ɥ�cin>>�Mcin.getline�|�����~�ҥH

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}
// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
   // memberDetails.size()
    for(int i=0;i< memberDetails.size();i++)
    {
        if(strcmp(memberDetails[i].idNumber,idNumber)==0 && strcmp(memberDetails[i].password, password)==0)
        {
            return true;
        }
    }
    cout << "\nInvalid account number or password. Please try again.\n";
    return false;
}
// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;

   for(int i=1;i<19;i++)
   {
       cout << setw(2) << i << "." << branchNames[i] << endl;
   }
   int choose;
   do
   {
       cout << "Enter your choice (0 to end):\n";
       cin >> choose;
       if (choose == 0)
       {
             cin.ignore();
             return; 
       }        
   } while (choose<1 ||choose>19);//0���ɭԷ|....
   //choose--;
   Date date;
   Date currentDate = compCurrentDate();
   date = currentDate;
   Date finaldate;
   cout << "The current hour is "<< currentDate.year<<"/"<< currentDate.month<<"/"<< currentDate.day << ":" << currentDate.hour;

   cout << "\nAvailable days:\n";
   for(int i=0;i<7;i++)
   {    
       cout<<setw(2)<<i+1<<"."<< date.year << "/" << date.month << "/" << date.day << endl;
       date.day += 1;
       if(date.day>31)
       {
           date.day -= 31;
           date.month += 1;
       }
     
   }
   int choosetime;
   do
   {
       cout << "\nEnter your choice (0 to end):";
       cin >> choosetime;
       if(choosetime==0)
       {
           cin.ignore();
           return;      
       }
   } while (choosetime < 1 || choosetime>7);
   finaldate.day = currentDate.day + choosetime - 1;
   finaldate.month = currentDate.month;
   if(finaldate.day>31)
   {
       finaldate.day -= 31;
       finaldate.month += 1;
   }
   finaldate.year = currentDate.year;

   int choosehour;
   int wrong = 0;
   do
   {
       int signal=0;
       if(choosetime!=1)
       {
         cout << "Enter hour (1~23):";
       }
       else
       {
           signal = 1;
           cout << "Enter hour ("<<currentDate.hour+1<<"~23):";
       }      
       cin >> choosehour;
       wrong = 0;
       if (signal==1) 
       {
           if (choosehour < currentDate.hour || choosehour>23)
               wrong+=1;
       }
   } while (choosehour < 1 || choosehour>23 || wrong!=0);
   finaldate.hour = choosehour;
   int cus;
   do
   {
       cout << "Enter the number of customers (1~30, 0 to end):";
       cin >> cus;
       if (cus == 0)
       {
           cin.ignore();
           return;
       }
   } while (cus< 1 || cus>30);

   newReservation.numCustomers = cus;
   newReservation.branchCode = choose;
   for(int i=0;i<12;i++)
   {
    newReservation.idNumber[i] = idNumber[i];
   }
   newReservation.date = finaldate;

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
   cin.ignore();
}
// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();

   Date date[7];
   for (int i = 0; i < 7; i++)
   {
       date[i] = currentDate;
   }
   for (int i = 0; i < 7; i++)
   { 
       date[i].day += i;
   }
   for (int i = 0; i < 7; i++)
   {
       if (date[i].day > 31)
       {
           date[i].day -= 31;
           date[i].month += 1;
       }
   }
   for (int i = 0; i < 7; i++)
   {
       availableDates[i] = date[i];
   }
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}
// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
  // ReservationRecord list[200];
   vector< ReservationRecord > list;
   int index[200]{};
   int order = 1;
   int signal = 0;
   for(int i=0;i< reservations.size();i++)
   {
       if(strcmp(reservations[i].idNumber, idNumber) == 0 && !lessEqual(reservations[i].date, currentDate))//�Y�^�ҥ~���p
       {
          cout << order++<<".";
          output(reservations[i]);
          index[order++] = i;
         reservations.push_back(reservations[i]);
         signal = 1;
         break;//
       } 
   }
   if (signal == 0)
   {
       cout << "No reservations!" << endl;
       return;
   }
   int cancel = 0;
  do
  {
      cout << "\nChoose a reservation to cancel (0: keep all reservations):";
      cin >> cancel;
      if (cancel == 0)
          break;
     reservations.push_back(reservations[index[cancel]]);
     reservations.pop_back();
     //reservations.erase(index[cancel]);
  } while (cancel<0 || cancel>order);
   cin.ignore();
}
// add a new member
void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}
// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for(int i=0;i<memberDetails.size();i++)
    {
        if(strcmp(idNumber, memberDetails[i].idNumber)==0)
        {
            return true;
        }
    }
    return false;
}
// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    std::fstream member("Members.dat", ios::in | ios::out | ios::binary);
    if (!member)
    {
        std::cerr << "flie could not be opend";
        exit(1);
    }
    member.seekg(0, ios::end);
    for (int i = 0; i < memberDetails.size(); i++)
    {
        member.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));//memberDetails[i]
    }
    member.close();
}
// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations )
{
    std::fstream refile("Reservations.dat", ios::in | ios::out | ios::binary);
    if (!refile)
    {
        std::cerr << "flie could not be opend";
        exit(1);
    }
    refile.seekg(0, ios::end);

    Date current = compCurrentDate();
    for(int i=0;i<reservations.size();i++)
    {
        if (!lessEqual(reservations[i].date, current))// date1 <= date2
        {
            refile.write(reinterpret_cast< const char*>(&reservations[i]), sizeof(ReservationRecord));//memberDetails[i]
        }     
    }
    refile.close();
}