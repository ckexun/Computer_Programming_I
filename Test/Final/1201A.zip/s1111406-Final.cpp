#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    // read all memberDetails from the file Members.dat
    ifstream memberdetailFile("Members.dat", ios::in | ios::binary);
    memberdetailFile.seekg(0, ios::beg);
    memberdetailFile.read(reinterpret_cast<char*>(&memberDetails), sizeof(MemberRecord));
    /*
    int num = 0;
    while (memberdetailFile.read(reinterpret_cast<char*>(&memberDetails[num]), sizeof(MemberRecord))) {
        cout << "good" << endl;
        num++;
    }
    num--;
    cout << num << endl;
    */
    memberdetailFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    // read all reservations that are not out of date, from the file Reservations.dat
    ifstream reservationsFile("Reservations.dat", ios::in | ios::binary);
    reservationsFile.seekg(0, ios::beg);
    ReservationRecord tmp;
    int num = 0;
    Date currentDate = compCurrentDate();
    
    while (reservationsFile.read(reinterpret_cast<char*>(&tmp), sizeof(ReservationRecord))) {
        if (lessEqual(currentDate, tmp.date)) {
            reservations[num] = tmp;
            num++;
        }
    }
    num--;
    reservationsFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0); // �n��U�@�Ѫ� + 24 * 60 * 60
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year) {
        return true;
    }
    else if (date1.year == date2.year) {
        if (date1.month < date2.month) {
            return true;
        }
        else if (date1.month == date2.month) {
            if (date1.day < date2.day) {
                return true;
            }
            else if (date1.day == date2.day) {
                if (date1.hour < date2.hour) {
                    return true;
                }
                else if (date1.hour == date2.hour) {
                    return false;
                }
                else if (date1.hour > date2.hour) {
                    return false;
                }
            }
            else if (date1.day > date2.day) {
                return false;
            }
        }
        else if (date1.month > date2.month) {
            return false;
        }
    }
    else if (date1.year > date2.year) {
        return false;
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;
        
        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    // there exists a member with specified idNumber and password
    if (memberDetails.size() == 0) {
        cout << "\nInvalid account number or password. Please try again.\n";
        return false;
    }
    else {
        for (int num = 0; num < memberDetails.size(); num++) {
            if (strcmp(idNumber, memberDetails[num].idNumber) == 0 && strcmp(password, memberDetails[num].password) == 0) {
                return true;
            }
            else if ((num + 1) == memberDetails.size()) {
                cout << "\nInvalid account number or password. Please try again.\n";
                return false;
            }
        }
    }
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    // add a new reservation for the member with specified IDnumber
    ReservationRecord newReservation;
    for (int i = 1; i <= 18; i++) {
        cout << setw(2) << i << ". " << branchNames[i] << endl;
    }

    do {
        cout << "\nEnter your choice (0 to end): ";
        cin >> newReservation.branchCode;
    } while (newReservation.branchCode < 0 || newReservation.branchCode > 18);

    Date currentDate = compCurrentDate();
    cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

    Date availableDates[8];
    cout << "\nAvailable days: \n";
    compAvailableDates(availableDates);
    for (int i = 1; i <= 7; i++) {
        cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
    }

    int choice;
    do {
        cout << "\nEnter your choice(0 to end): ";
        cin >> choice;
    } while (choice < 0 || choice > 7);
    newReservation.date.year = availableDates[choice].year;
    newReservation.date.month = availableDates[choice].month;

    int hour = currentDate.hour + 1;
    if (currentDate.hour == 23)
        hour = 0;
    do {
        cout << "\nEnter hour (" << hour << "~23): ";
        cin >> newReservation.date.hour;
    } while (newReservation.date.hour < hour || newReservation.date.hour > 23);

    do {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers > 30);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    newReservation.date.day = availableDates[choice].day;
    for (int i = 0; i <= 11; i++) {
        newReservation.idNumber[i] = idNumber[i];
    }

    output(newReservation);
    cin.ignore();
    cout << "\nReservation Completed!\n";
    reservations.push_back(newReservation);
    
}

void compAvailableDates(Date availableDates[])
{
    // compute 7 dates which is starting from the current date
    Date currentDate = compCurrentDate();
    int year = currentDate.year;
    int month = currentDate.month;
    int day = currentDate.day;
    int arr[13] = { 0,31,0,31,30,31,30,31,31,30,31,30,31 };
    if (currentDate.hour == 23) { // �n��U�@��
        if (currentDate.day == 30 || currentDate.day == 31 || currentDate.day == 0) {
            day = 1;
            if (currentDate.month == 12) {
                year++;
                month = 1;
            }
            else
                month++;
        }
        else {
            month++;
            day++;
        }
    }
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
        arr[2] = 29;
    }
    else if (year % 100 && year % 400 != 0) {
        arr[2] = 28;
    }
    for (int i = 1; i <= 7; i++) {
        availableDates[i] = { year, month, day };
        if (day == arr[month]) { // ����̫�@��
            if (month == 12) {
                year++;
                month = 1;
                day = 1;
            }
            else {
                day = 1;
                month++;
            }
        }
        else {
            day++;
        }
    }
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    // display all reservations for the member with specified IDnumber,
    // then let the member to choose one of them to delete
    Date currentDate = compCurrentDate();
    int num = 0;
    for (int i = 0; i < reservations.size(); i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0) {
            num++;
        }
    }
    if (num == 0) {
        cout << "No reservations!" << endl;
    }
    else {
        num = 0;
        cout << endl << setw(28) << "Branch"
            << setw(15) << "Date" << setw(9) << "Hour"
            << setw(20) << "No of Customers" << endl;
        for (int i = 0; i < reservations.size(); i++) {
            if (strcmp(idNumber, reservations[i].idNumber) == 0) {
                num++;
                cout << num << ". ";
                output(reservations[i]);
            }
        }
        int choice;
        do {
            cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
            cin >> choice;
        } while (choice > num || choice < 0);
        if (choice == 0) {
            return;
        }
        else { // delete
            for (int i = 0; i < reservations.size(); i++) {
                num = 0;
                if (strcmp(idNumber, reservations[i].idNumber) == 0) {
                    num++;
                }
                if (choice == num) {
                    // reservations[i].numCustomers = -1;
                }
            }
        }
    }
    cin.ignore();
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    // return true if idNumber belongs to memberDetails
    // cout << memberDetails[0].idNumber << endl;
    if (memberDetails.size() == 0) {
        return false;
    }
    else {
        for (int num = 0; num < memberDetails.size(); num++) {
            if (strcmp(idNumber, memberDetails[0].idNumber) == 0) {
                return true;
            }
            else if (num == memberDetails.size()) {
                return false;
            }
        }
    }
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    // write all memberDetails into the file Members.dat
    ofstream memberFile("Members.dat", ios::out | ios::binary);
    memberFile.seekp(0, ios::beg);
    memberFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    /*
    int num = 0;
    while (memberFile.write(reinterpret_cast<const char*>(&memberDetails[num]), sizeof(MemberRecord))) {
        num++;
    }
    memberFile.close();
    */
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    // write all reservations that are not out of date, into the file Reservations.dat
    ofstream reservationFile("Reservations.dat", ios::out | ios::binary);
    reservationFile.seekp(0, ios::beg);
    reservationFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    /*
    int num = 0;
    while (reservationFile.write(reinterpret_cast<const char*>(&reservations[num]), sizeof(ReservationRecord))) {
        num++;
    }
    reservationFile.close();
    */
}