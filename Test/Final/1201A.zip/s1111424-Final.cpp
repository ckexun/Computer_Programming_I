#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::fstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

bool leepyear(int year);

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream inFile("Members.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "�}��Members.dat����";
        return;
    }
    int num = 0;
    while (1)
    {
        inFile.read(reinterpret_cast<char*> ( & memberDetails[++num]), sizeof(vector< MemberRecord >));//**********************
        if (inFile.eof())
            break;
    }
    num -= 1;
    inFile.close();

}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream inFile("Reservations.dat", ios::in | ios::binary);
    if (!inFile)
    {
        cout << "�}��Reservations.dat����";
        return;
    }
    int num = 0;
    while (1)
    {
        inFile.read(reinterpret_cast<char*> (&reservations[++num]), sizeof(vector< MemberRecord >));//**********************
        if (inFile.eof())
            break;
    }
    num -= 1;
    inFile.close();

}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;
   //cout << currentDate.year <<"/" << currentDate.month <<"/" << currentDate.day<<"/"<< currentDate.hour;
   return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 )
{
    
    if (date1.year <= date2.year)
        return true;
    if (date1.month <= date2.month)
        return true;
    if (date1.day <= date2.day)
        return true;
    if (date1.hour <= date2.hour)
        return true;
    else
        return false;

}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for(int i=1;i<12;i++)
    { 
        if (strcmp(idNumber, memberDetails[i].idNumber) != 0)
        {
            cout << "Invalid account number or password. Please try again.";
            return true;
        }
            
    }
    for (int i = 1; i < 24; i++)
    if (strcmp(password, memberDetails[i].password) != 0)
    {
        cout << "Invalid account number or password. Please try again.";
        return true;
    }
    else
        return false;
    
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )//!!!!!!!!!!!!!!!!!!!
{
   ReservationRecord newReservation;
   //�C�X�Ҧ����d����
   for (int i = 1; i <= 18; i++)
   {
       cout << i << ". " << branchNames[i][24] << endl;
   }
   int choiceCashBox;
   //���ƿ�J��ܪ��쥿�T
   while (1)
   {
       cout << "\nEnter your choice(0 to end): ";
       cin >> choiceCashBox;
       if ((choiceCashBox >= 1) && (choiceCashBox <= 18))
           break;
   }

  
   cout << "The current hour is ";
   Date tmpDate=compCurrentDate();//��ܥثe�~/��/��/�p��
   cout << tmpDate.year << "/" << tmpDate.month << "/" << tmpDate.day << "/" << tmpDate.hour;
   cout << endl;

  
   int yy = tmpDate.year;
   int mm = tmpDate.month;
   int dd = tmpDate.day;
   int hh = tmpDate.hour;
   char days[][4] = { "","31","28","31","30","31","30","31","31","30","31","30","31" };
   if (leepyear)
       days[2][4] = { 29};

   int starthour=0;//�q���ɶ�

   //�C�X�q���ѩ��᪺6�Ѥ��
   cout << "Available days: \n";
   for (int i = 1; i <= 7; i++)
   {
       cout << i << ". " << yy << mm << dd<<endl;
       dd += 1;
       if (dd > (int)days[mm])
       {
           mm += 1;
           dd = 1;
           if (mm > 12)
           {
               yy += 1;
               mm = 1;
               if (leepyear)
                   days[2][4] = { 29 };
           }
       }
   }

   //���ƿ�ܤ�������ܥ��T
   int choicedate;
   while (1)
   {
       cout << "Enter your choice (0 to end): ";
       cin >> choicedate;
       if ((choicedate >= 1) && (choicedate <= 7))
       {
           dd += choicedate - 1;//�ץ���dd���n�q�������
           break;
       }
           

   }
   //�p�G��ܷ���w�w�A�h��ܷ���ثe�ɶ�����@�Ӥp�ɶ}�l
   if (choicedate == 1)
   {
    starthour = hh+1;
    if (starthour > 24)//�p�G��� �h�}�l�ɶ����s //!!�����D��򭭨����w���F(bug)!!
        starthour = 0;
   }
       
   //��ܹw�w�ɶ�
   int choicehour;
   while (1)
   {
       cout << "Enter hour ("<<starthour<<"~"<<"23): ";
       cin >> choicehour;
       cout << endl;
       if ((choicehour >= starthour) && (choicehour <= 23))
           break;
   }

   //��ܫȤH�ƶq
   int numcustomers;
   while (1)
   {
       cout << "Enter the number of customers (1~30, 0 to end): ";
       cin >> numcustomers;
       cout << endl;
       if ((numcustomers >= 1) && (numcustomers <= 30))
           break;
       
   }
   newReservation.date.year = yy;
   newReservation.date.month = mm;
   newReservation.date.day = dd;
   newReservation.date.hour = hh;
   newReservation.numCustomers = numcustomers;
   newReservation.branchCode = choiceCashBox;


   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   
   return;



}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}
//return true if leepyear
bool leepyear(int year)
{
    //��400�����ơA�|�~
    if ((year % 400) == 0)
        return true;
    //��4�����Ʀ��D100������
    if (((year % 4) == 0) && ((year % 100) != 0))
        return true;
    //��100�����Ʀ��D400�����ơA���~
    if (((year % 100) == 0) && ((year % 400) != 0))
        return false;   
}
// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   saveReservations(reservations);
   vector< ReservationRecord > tmp= reservations;
   for (int i = 1; i <= 12; i++)//�ڤ����D���X��reservations
   {
       if (strcmp(idNumber, reservations[i].idNumber) == 0)
       {
           tmp[i].idNumber = idNumber;
            break;
       }
           
       else if(i==12)
           cout<<"No reservations!";
   }
   int found = 0;
   for (int i = 1; i <= 10; i++)//���T�w���X���q��A�Ȯɥ�10�N��
   {
       cout << ++found << ". "; output(tmp);//��X�����q��
   }

   //��X�n�R�����Ǹ�
   int deleteNumber;
   while (1)
   {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> deleteNumber;
        if ((deleteNumber > 0) && (deleteNumber <= numreservation))
            break;
   }
	


}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 1; i < 12; i++)
    {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0)
            return true;
    }
    return false;
}


// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    fstream ioFile("Members.dat", ios::in|ios::out | ios::binary);

    if (!ioFile)
    {
        cout << "�}Members.dat����";
        return;
    }
    ioFile.seekp(0, ios::beg);//�����ƭ��g
    while (1)
    {
        if(ioFile.eof())
            break;
        ioFile.write(reinterpret_cast<const char*>(&memberDetails), sizeof(MemberRecord));
    }
   
    ioFile.clear();//���T�w
    ioFile.close();
}

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations )    
{
    fstream ioFile("Reservations.dat", ios::out|ios::in | ios::binary);

    if(!ioFile)
    {
        cout << "�}Reservations.dat����";
        return;
    }

    ioFile.seekg(0, ios::beg);
    while (1)
    {
        if (ioFile.eof())
            break;
        ioFile.write(reinterpret_cast<const char*>(&reservations), sizeof(ReservationRecord));
    }
    
    ioFile.clear();
    ioFile.close();
}
