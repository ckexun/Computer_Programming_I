#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream file("Members.dat", ios::binary);
    file.seekg(0, ios::end);
    int n = static_cast<int>(file.tellg()) / sizeof(MemberRecord);
    file.seekg(0, ios::beg);
    MemberRecord tmp;
    for (int i = 0; i < n; i++) {
        file.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
        memberDetails.push_back(tmp);
        
    }
    file.close();


}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream file("Reservations.dat", ios::binary);
    file.seekg(0, ios::end);
    int n = static_cast<int>(file.tellg()) / sizeof(ReservationRecord);
    file.seekg(0, ios::beg);
    ReservationRecord tmp;
    Date cur = compCurrentDate();

    for (int i = 0; i < n; i++) {
        file.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
        if (lessEqual(cur, tmp.date)) {
            reservations.push_back(tmp);
        }

    }




    file.close();
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time(0);
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    

    if (date2.year < date1.year)
        return false;

    if (date2.year > date1.year)
        return true;

    //date2.year == date1.year
    if (date2.month < date1.month)
        return false;
    if (date2.month > date1.month)
        return true;

    //date2.month == date1.month
    if (date2.day < date1.day)
        return false;
    if (date2.day > date1.day)
        return true;

    //date2.v == date1.month
    if (date2.hour < date1.hour)
        return false;

    return true;
}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if (!strcmp(idNumber, memberDetails[i].name))
        {
            if (!strcmp(password, memberDetails[i].password))
                return true;
            break;
        }

    }
    cout << "\nInvalid account number or password. Please try again.\n\n";
    return false;


}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation;
   strcpy_s(newReservation.idNumber, idNumber);
   int branchChoise;
   for (int i = 1; i <= 18; i++)
       cout << setw(2) << i << ". " << branchNames[i] << endl;
   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> branchChoise;
       cin.ignore();
       if (!branchChoise)
           return;
   } while (branchChoise < 1 || branchChoise>18);
   

   newReservation.branchCode = branchChoise;

   Date availableDates[8];
   compAvailableDates(availableDates);
   cout << "\nAvailable days:\n\n";
   int dateChoise;
   for (int i = 1; i < 8; i++)
       cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;

   do {
       cout << "\nEnter your choice (0 to end): ";
       cin >> dateChoise;
       cin.ignore();
       if (!dateChoise)
           return;
   } while (dateChoise < 1 || dateChoise>7);
   newReservation.date = availableDates[dateChoise];

   do {
       cout << "\nEnter hour (" << availableDates[dateChoise].hour << "~" << "23): ";
       cin >> newReservation.date.hour;

   } while (newReservation.date.hour < availableDates[dateChoise].hour || newReservation.date.hour>23);
   do {
       cout << "\nEnter the number of customers (1~30, 0 to end): ";

       cin >> newReservation.numCustomers;
       cin.ignore();
       if (!newReservation.numCustomers)
           return;

   } while (newReservation.numCustomers < 1 || newReservation.numCustomers>30);




   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
   Date currentDate = compCurrentDate();
   int days[2][13] = { {0,31,28,31,30,31,30,31,31,30,31,30,31 },{0,31,29,31,30,31,30,31,31,30,31,30,31 } };
   cout << "\nThe current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;
   currentDate.hour++;
   int Y = 0;
   if (currentDate.month == 2 && currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
       Y = 1;

   if (currentDate.hour == 24) {
       currentDate.day++;
       currentDate.hour = 0;
       if (days[Y][currentDate.month] < currentDate.day) {
           currentDate.month++;
           currentDate.day = 1;
       }

       if (currentDate.month == 13) {
           currentDate.year++;
           currentDate.month = 1;
           
           Y = 0;
           if (currentDate.month == 2 && currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
               Y = 1;
       }
   }

   for (int i = 1; i < 8; i++) {
       availableDates[i] = currentDate;
       currentDate.day++;
       currentDate.hour = 0;
       if (days[Y][currentDate.month] < currentDate.day) {
           currentDate.month++;
           currentDate.day = 1;
       }

       if (currentDate.month == 13) {
           currentDate.year++;
           currentDate.month = 1;
           Y = 0;
           if (currentDate.month == 2 && currentDate.year % 400 == 0 || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
               Y = 1;           

       }

   }


}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();
   int flag = 0, choise;
   for (int i = 0; i < reservations.size(); i++) {
       if (!strcmp(reservations[i].idNumber, idNumber)&& lessEqual(currentDate, reservations[i].date)) {
           if (flag == 0) {
               cout << endl << setw( 28 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;
           }
           cout << ++flag << ".";
           output(reservations[i]);

       }

   }
   if (!flag) {
       cout << "No reservations!\n";
       return;

   }
   do {
       
       cout << "\nChoose a reservation to cancel (0: keep all reservations): ";
       cin >> choise;
       cin.ignore();
       if (!choise)
           return;
   } while (choise < 1 || choise>flag);

   vector< ReservationRecord >tmp;

   for (int i = 0; i < reservations.size(); i++) {
       if (!strcmp(reservations[i].idNumber, idNumber) && lessEqual(currentDate, reservations[i].date)) 
           choise--;
       if (!choise || !lessEqual(currentDate, reservations[i].date))
           continue;
       tmp.push_back(reservations[i]);

   }
   reservations = tmp;

}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++) {
        if(!strcmp(memberDetails[i].idNumber, idNumber))
            return true;
    }
    return false;


}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream file("Members.dat", ios::binary);
    for (int i = 0; i < memberDetails.size(); i++) 
        file.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(memberDetails[i]));

    file.close();

}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream file("Reservations.dat", ios::binary);
    for (int i = 0; i < reservations.size(); i++) 
        file.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(reservations[i]));
        
    
    file.close();

}