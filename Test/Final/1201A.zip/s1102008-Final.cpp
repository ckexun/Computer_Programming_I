#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    //openfile
    int idx;
    char ch, filename[100] = "Members.dat";
    ifstream readFile(filename, ios::in | ios::binary | ios::app);
    
    //fail open file
    if (!readFile)
    {
        cout << "Error : Fail to open file :" << filename << endl;
        exit(1);
    }

    //read
    idx = 0;
    while (readFile.get(ch)) 
    {
        if (ch == '/n')
            idx++;
        //read id
        for (int i = 0; i < 12; i++)
        {
            *memberDetails[idx].idNumber += ch;
        }
        //read name
        for (int i = 0; i < 8; i++)
        {
            *memberDetails[idx].name += ch;
        }
        //read password
        for (int i = 0; i < 24; i++)
        {
            *memberDetails[idx].password += ch;
        }
    }
    
    readFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    //openfile
    int idx;
    char ch, filename[100] = "Reservations.dat";
    ifstream readFile(filename, ios::in | ios::binary);

    //fail open file
    if (!readFile)
    {
        cout << "Error : Fail to open file :" << filename << endl;
        exit(1);
    }

    //read
    idx = 0;
    while (readFile.get(ch))
    {
        if (ch == '/n')
            idx++;
        //read id
        for (int i = 0; i < 12; i++)
        {
            *reservations[idx].idNumber += ch;
        }
        //read branchCode
        for (int i = 0; i < 26; i++)
        {
            reservations[idx].branchCode += ch;
        }
        //read year
        for (int i = 0; i < 8; i++)
        {
            reservations[idx].date.year += ch;
        }
        //read month
        for (int i = 0; i < 2; i++)
        {
            reservations[idx].date.month += ch;
        }
        //read day
        for (int i = 0; i < 2; i++)
        {
            reservations[idx].date.day += ch;
        }
        //read hour
        for (int i = 0; i < 8; i++)
        {
            reservations[idx].date.hour += ch;
        }
        //read numCustomers
        for (int i = 0; i < 19; i++)
        {
            reservations[idx].numCustomers += ch;
        }
    }

    readFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
        return true;
    else if (date1.year > date2.year)
        return false;
    else if (date1.year == date2.year)
    {
        if (date1.month < date2.month)
            return true;
        else if (date1.month > date2.month)
            return false;
        else if (date1.month == date2.month)
        {
            if (date1.day <= date2.day)
                return true;
            else if (date1.day > date2.day)
                return false;
        }
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (idNumber == memberDetails[i].idNumber && password == memberDetails[i].password)
            return true;
    }
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;
    Date newCurrentDate = compCurrentDate();
    int choice;
    int monthDays[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int year = newCurrentDate.year, month = newCurrentDate.month, day = newCurrentDate.day, hour = newCurrentDate.hour;

    strcpy_s(newReservation.idNumber, idNumber);

    //branchNames
    for (int i = 1; i <= 18; i++)
    {
        cout << i << ". " << branchNames[i] << endl;
    }

    choice = 0;
    while(choice < 1 || choice > 18)
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
    }
    newReservation.branchCode = choice;

    //show current time
    cout << "\nThe current hour is " << newCurrentDate.year << "/'" << newCurrentDate.month << "/'" << newCurrentDate.day << ":" << newCurrentDate.hour << endl;

    //seven days
    vector< ReservationRecord >seven;
    cout << "\nAvailable days:" << endl;

    for (int i = 1; i <= 7; i++)
    {
        //almost over shop open time
        if (newCurrentDate.hour >= 23)
        {
            day++;
            if (day > monthDays[month])
            {
                day = 1;
                month++;
            }
            if (month >= 13)
            {
                month = 1;
                year++;
            }
        }
        //copy date
        seven[i].date.year = year;
        seven[i].date.month = month;
        seven[i].date.day = day;

        cout << i << ". " << year << "/'" << month << "/'" << day << endl;
        day++;

        if (day > monthDays[month])
        {
            day = 1;
            month++;
        }
        if (month >= 13)
        {
            month = 1;
            year++;
            if (((year % 4 == 0) && (year % 100 != 0)) || year % 400 == 0)
                monthDays[2] += 1;
        }
    }

    choice = 0;
    while (choice < 1 || choice > 7)
    {
        cout << "\nEnter your choice (0 to end): ";
        cin >> choice;
    }
    newReservation.date.year = seven[choice].date.year;
    newReservation.date.month = seven[choice].date.month;
    newReservation.date.day = seven[choice].date.day;
    
    //min time could accpet
    //except choice 1, other hours go 0~23
    if (choice == 1)
    {
        while (choice < hour + 1 || choice > 23)
        {
            cout << "\nEnter hour (" << hour + 1 << "~" << 23 << "): ";
            cin >> choice;
        }
    }
    else
    {
        choice = 24;
        while (choice < 0 || choice > 23)
        {
            cout << "\nEnter hour (0~23): ";
            cin >> choice;
        }
    }

    //copy hour
    newReservation.date.hour = choice;

    choice = -1;
    //choosing number of people
    while (choice < 0 || choice > 30)
    {
        cout << "\nEnter the number of customers (1~30, 0 to end): ";
        cin >> choice;
    }
    newReservation.numCustomers = choice;

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);

    saveReservations(reservations);
}

void compAvailableDates(Date availableDates[])
{
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();
    int idx = 0;
    int choice;
    
    //check the past time and delete
    for (int i = 0; i < reservations.size(); i++)
    {
        if (lessEqual(reservations[i].date, currentDate))
        {
            reservations[i] = reservations[i + 1];
            reservations[i + 1].date.year = '\0';
            reservations[i + 1].date.month = '\0';
            reservations[i + 1].date.day = '\0';
            reservations[i + 1].date.hour = '\0';
            reservations[i + 1].branchCode = '\0';
            for (int j = 0; j < 12; j++)
            {
                reservations[i + 1].idNumber[j] = '\0';
            }
            reservations[i + 1].idNumber[0] = '\0';
            reservations[i + 1].numCustomers = '\0';
        }
    }

    cout << endl << setw(29) << "Branch"
         << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    //print the data
    for (int i = 0; i < reservations.size(); i++)
    {
        if (reservations[i].idNumber == idNumber)
        {
            idx++;
            cout << idx<<". "<< setw(26) << "Branch" 
                 << setw(14) << "Date" << setw(8) << "Hour"
                 << setw(19) << "No of Customers" << endl;
        }
    }

    //choose the data that is going to delete
    choice = 0;
    while (choice < 1 || choice >= reservations.size())
    { 
        cout << "Choose a reservation to cancel(0: keep all reservations) : ";
        cin >> choice;
    }
    
    //delete
    for (int i = choice - 1; i < reservations.size() - 1; i++)
    { 
        reservations[i] = reservations[i + 1];
    }
    reservations[reservations.size()].date.year = '\0';
    reservations[reservations.size()].date.month = '\0';
    reservations[reservations.size()].date.day = '\0';
    reservations[reservations.size()].date.hour = '\0';
    reservations[reservations.size()].branchCode = '\0';

    for (int j = 0; j < 12; j++)
    {
        reservations[reservations.size()].idNumber[j] = '\0';
    }
    reservations[reservations.size()].idNumber[0] = '\0';
    reservations[reservations.size()].numCustomers = '\0';
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (idNumber == memberDetails[i].idNumber)
            return true;
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    char filename[100] = "Members.dat";
    ofstream outFile(filename, ios::out | ios::app);
    if (!outFile)
    {
        cout << "Error : Fail to open file : "<< filename << endl;
        exit(1);
    }
    for (int i = 0; i < memberDetails.size(); i++)
    {
        outFile << setw(12) << memberDetails[i].idNumber
                << setw(8) << memberDetails[i].name
                << setw(24) << memberDetails[i].password << endl;
    }

    outFile.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    char filename[100] = "Reservations.dat";
    ofstream outFile(filename, ios::out | ios::app);
    if (!outFile)
    {
        cout << "Error : Fail to open file : " << filename << endl;
        exit(1);
    }

    for (int i = 0; i < reservations.size(); i++)
    { 
        outFile << setw(12) << reservations[i].idNumber
                << setw(26) << reservations[i].branchCode
                << setw(8) << reservations[i].date.year
                << setw(2) << reservations[i].date.month
                << setw(2) << reservations[i].date.day
                << setw(8) << reservations[i].date.hour
                << setw(19) << reservations[i].numCustomers << endl;
    }
    outFile.close();
}
