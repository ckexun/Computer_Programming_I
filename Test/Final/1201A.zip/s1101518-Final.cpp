#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
bool legalID(char idNumber[]);

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{

    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations



    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream loadFile("Members.dat", ios::binary);
    if (!loadFile)
    {
        cout << "File could not be open." << endl;
        system("pause");
        exit(1);
    }

    loadFile.seekg(0, ios::end);
    int dataNum = loadFile.tellg() / sizeof(MemberRecord);
    loadFile.seekg(0, ios::beg);

    MemberRecord store;
    for (int i = 0; i < dataNum; i++)
    {
        loadFile.read(reinterpret_cast<char*>(&store), sizeof(MemberRecord));
        memberDetails.push_back(store);
    }

    loadFile.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream inFile("Reservations.dat", ios::binary);
    if (!inFile)
    {
        cout << "File could not be open." << endl;
        system("pause");
        exit(1);
    }

    inFile.seekg(0, ios::end);
    int dataNum = inFile.tellg() / sizeof(ReservationRecord);
    inFile.seekg(0, ios::beg);

    ReservationRecord store;
    for (int i = 0; i < dataNum; i++)
    {
        inFile.read(reinterpret_cast<char*>(&store), sizeof(ReservationRecord));
        reservations.push_back(store);
    }

    inFile.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

bool lessEqual(const Date& date1, const Date& date2)
{

    if (date1.year > date2.year)
        return false;
    else if (date1.year < date2.year)
        return true;
    else
    {
        if (date1.month > date2.month)
            return false;
        else if (date1.month < date2.month)
            return true;
        else
        {
            if (date1.day > date2.day)
                return false;
            else
                return true;
        }
    }
}

int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{

    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    vector< MemberRecord > members;
    loadMemberDetails(members);
    int numMembers = members.size();

    char id[12] = "";
    char pword[24] = "";

    for (int i = 0; i < numMembers; i++)
    {
        for (int j = 0; j < 12; j++)
            id[j] = memberDetails[i].name[j];
        for (int j = 0; j < 24; j++)
            pword[j] = memberDetails[i].password[j];
        if (strcmp(id, idNumber) == 0 && strcmp(pword, password) == 0)
            return true;
    }

    cout << "Invalid account number or password. Please try again." << endl;
    return false;
}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    Date current = compCurrentDate();

    for (int i = 1; i <= 18; i++)
        cout << i << ". " << branchNames[i] << endl;

    int b_cho;
    do {

        cout << "Enter your choice (0 to end): ";
        cin >> b_cho;
        cin.ignore();

        if (b_cho == 0)
            return;

    } while (b_cho < 0 || b_cho>18);
    newReservation.branchCode = b_cho;

    Date availableDates[8];
    compAvailableDates(availableDates);

    int d_cho;
    do {

        cout << "Enter your choice (0 to end): ";
        cin >> d_cho;
        cin.ignore();

        if (d_cho == 0)
            return;

    } while (d_cho < 0 || d_cho>7);
    newReservation.date = availableDates[d_cho];

    int h_start{ 0 };
    int h_cho;
    if (newReservation.date.day == current.day)
        h_start = current.hour + 1;
    do {

        cout << "Enter hour (" << h_start << "~23): ";
        cin >> h_cho;

    } while (h_cho < h_start || h_cho>23);
    newReservation.date.hour = h_cho;

    int n_cho;
    do {

        cout << "Enter the number of customers (1~30, 0 to end): ";
        cin >> n_cho;
        cin.ignore();

        if (n_cho == 0)
            return;

    } while (n_cho < 1 || n_cho>30);
    newReservation.numCustomers = n_cho;

    for (int i = 0; i < 12; i++)
        newReservation.idNumber[i] = idNumber[i];


    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);

    saveReservations(reservations);
}

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();
    cout << "The current hour is " << currentDate.year << '/' << currentDate.month << '/' << currentDate.day << ": " << currentDate.hour << endl;

    Date modDate;
    modDate = currentDate;

    int lastDay[12] = { 31,31,28,31,30,31,30,31,31,30,31,30 };
    if (currentDate.year % 400 == 0 || currentDate.year % 4 == 0 && currentDate.year % 100 != 0)
        lastDay[3] = 29;

    for (int i = 1; i < 8; i++)
    {
        if (currentDate.hour == 23)
            modDate.day++;
        if (modDate.day > lastDay[modDate.month % 12])
        {
            modDate.day = 1;
            modDate.month++;
            if (modDate.month == 13)
            {
                modDate.month = 1;
                modDate.year++;
                if (modDate.year % 400 == 0 || modDate.year % 4 == 0 && modDate.year % 100 != 0)
                    lastDay[3] = 29;
                else
                    lastDay[3] = 28;
            }
        }
        availableDates[i] = modDate;
        modDate.day++;
    }

    for (int i = 1; i < 8; i++)
        cout << i << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << endl;
}

void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{

    char idcheck[12] = " ";
    int i;
    for (i = 0; i < reservations.size(); i++)
    {
        for (int j = 0; j < 12; j++)
            idcheck[j] = reservations[i].idNumber[j];
        if (strcmp(idcheck, idNumber) == 0)
            break;
    }

    if (i == reservations.size())
    {
        cout << "No reservations!" << endl;
        return;
    }

    Date currentDate = compCurrentDate();

    /**/
    ReservationRecord sto;
    for (int j = 0; j < reservations.size(); j++)
    {
        if (!lessEqual(currentDate, reservations[j].date))
        {
            sto = reservations[reservations.size() - 1];
            reservations.pop_back();
            reservations[j] = sto;
        }
    }
    
    saveReservations(reservations);

    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    char idcheck2[12] = " ";
    int index{ 0 };
    int numReservation = reservations.size();
    for (int i = 0; i < numReservation; i++)
    {
        for (int j = 0; j < 12; j++)
            idcheck2[j] = reservations[i].idNumber[j];
        if (strcmp(idcheck2, idNumber) == 0)
        {
            index++;
            cout << index << ".";
            output(reservations[i]);
        }
    }

    int deleted;
    do {

        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> deleted;
        cout << endl;

        cin.ignore();

        if (deleted == 0)
            return;

    } while (deleted<0 || deleted>index);

    reservations[deleted - 1] = reservations[reservations.size() - 1];
    reservations.pop_back();

    saveReservations(reservations);
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    saveMemberDetails(memberDetails);

    cout << "\nRegistration Completed!\n\n";
}

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    char idcheck[12] = " ";
    int numMember = memberDetails.size();
    for (int i = 0; i < numMember; i++)
    {
        for (int j = 0; j < 12; j++)
            idcheck[j] = memberDetails[i].idNumber[j];
        if (strcmp(idcheck, idNumber) == 0)
            return true;
    }

    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream outFile("Members.dat", ios::binary);
    if (!outFile)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    for (int i = 0; i < memberDetails.size(); i++)
        outFile.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));

}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream outFile("Reservations.dat", ios::binary);
    if (!outFile)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    for (int i = 0; i < reservations.size(); i++)
        outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));

}