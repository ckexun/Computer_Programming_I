﻿#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    //ofstream outfile("Members.dat", ios::in | ios::out | ios::binary);

    ifstream infile("Members.dat", ios::in | ios::binary);

    if (!infile)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    //infile.read(reinterpret_cast<char*>(&memberDetails), 26);



    infile.close();
}

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream infile("Members.dat", ios::in | ios::binary);

    if (!infile)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }

    infile.read(reinterpret_cast<char*>( &reservations ), 26 );



    infile.close();
}

// compute the current date
Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}

//閏年規則
// 4的倍數但不為100的倍數，為閏年
// 100的倍數但不為400的倍數，為平年
// 400的倍數，為平年
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{

    //比較date1和date2
    cout << &date1;
    if ( &date1 <= &date2 )
        return true;
    else
        return false;

    return false;
}

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (!valid(idNumber, password, memberDetails));
    //使while的條件不不成立=成立
    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)
{
    MemberRecord member;
    ifstream infile("Members.dat" , ios::in | ios::binary );
    infile.read( member.idNumber , 12 );
    infile.read( member.password, 24 );
    if (member.idNumber == idNumber && member.password == password)
    {
        cout << "Invalid account number or password. Please try again." << endl;
        return false;
    }
    else
    {
        return true;
    }
}

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations)
{
    ReservationRecord newReservation;

    /*
    struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};
    */

    cin >> newReservation.idNumber;




    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();




}

// display all fields of reservation
void output(ReservationRecord reservation)
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    Date currentDate = compCurrentDate();



}

// add a new member
void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

//不知道vector裡面的structure是甚麼意思
// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    //不知道要怎麼把member裡面的資料取出來
    //先讀取檔案，再做確認

    ifstream infile("Members.dat", ios::in | ios::binary);
    
    MemberRecord member;

    infile.read(member.idNumber, 12);

    MemberRecord user;

    //infile.read(reinterpret_cast<char*>(&memberDetails), 26);

    //cout << "idNumber=   " << idNumber << endl;
    //cout << "user.idNumber=   " << user.idNumber << endl;


    if (idNumber == user.idNumber)
    {
        return true;
    }
    else
    {
        return false;
    }

    //if(strcmp( idNumber , memberDetails))
    //cout << memberDetails.begin();
}

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream file("Members.dat",  ios::out | ios::binary);
    if (!file)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }


    file.write( reinterpret_cast< const char* > (&memberDetails), 26);


    file.close();
}

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream file("Reservations.dat", ios::out | ios::binary);
    if (!file)
    {
        cout << "File could not be opened." << endl;
        system("pause");
        exit(1);
    }


    file.write(reinterpret_cast<const char*> (&reservations), 26);


    file.close();
}