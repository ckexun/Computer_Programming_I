#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
   int year;
   int month;
   int day;
   int hour;
};

struct MemberRecord
{
   char idNumber[ 12 ];   // account number
   char password[ 24 ];   // password
   char name[ 8 ];        // name
};

struct ReservationRecord
{
   char idNumber[ 12 ]; // account number
   int branchCode;      // branch code
   Date date;           // reservation date
   int numCustomers;    // number of customers
};

char branchNames[ 19 ][ 24 ] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails( vector< MemberRecord > &memberDetails );

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations( vector< ReservationRecord > &reservations );

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// login and display the submenu
void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations );

// there exists a member with specified idNumber and password
bool valid( char idNumber[], char password[],
            const vector< MemberRecord > &memberDetails );

// add a new reservation for the member with specified IDnumber
void reservation( char idNumber[], vector< ReservationRecord > &reservations );

// compute 7 dates which is starting from the current date
void compAvailableDates( Date availableDates[] );

// display all fields of reservation
void output( ReservationRecord reservation );

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete( char idNumber[], vector< ReservationRecord > &reservations );

// add a new member
void registration( vector< MemberRecord > &memberDetails );

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails );

// write all memberDetails into the file Members.dat
void saveMemberDetails( const vector< MemberRecord > &memberDetails );

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations( const vector< ReservationRecord > &reservations );

int main()
{
   vector< MemberRecord > memberDetails; // member details for all members
   vector< ReservationRecord > reservations; // all reservations

   loadMemberDetails( memberDetails );
   loadReservations( reservations );

   cout << "Welcome to the Cashbox Party World!\n\n";

   int choice;
   while( true )
   {
      cout << "1 - Login\n";
      cout << "2 - Registration\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         login( memberDetails, reservations );
         break;

      case 2:
         registration( memberDetails );
         break;

      case 3:
         saveMemberDetails( memberDetails );
         saveReservations( reservations );
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }

   system( "pause" );
}

void loadMemberDetails( vector< MemberRecord > &memberDetails )
{
    ifstream infile("Members.dat", ios::binary);
    size_t s;
    infile.seekg(ios::end);
    s = infile.tellg() / sizeof(MemberRecord);
    infile.seekg(ios::beg);
    for (int i = 0; i < s; i++)
    {
        infile.seekg(i * sizeof(MemberRecord));
        MemberRecord newRecord;
        infile.read(newRecord.idNumber, 4);
        infile.read(newRecord.password, 4);
        infile.read(newRecord.name, 4);

        memberDetails.push_back(newRecord);
    }
}

void loadReservations( vector< ReservationRecord > &reservations )
{
    ifstream infile("Reservations.dat", ios::binary);
    size_t s;
    infile.seekg(ios::end);
    s = infile.tellg() / sizeof(ReservationRecord);
    infile.seekg(ios::beg);
    for (int i = 0; i < s; i++)
    {
        infile.seekg(i*sizeof(ReservationRecord));
        ReservationRecord newRecord;
        infile.read(newRecord.idNumber, sizeof(newRecord.idNumber));
        infile.read(reinterpret_cast<char*>(&newRecord.branchCode), sizeof(newRecord.branchCode));
        infile.read(reinterpret_cast<char*>(&newRecord.date), sizeof(newRecord.date));
        infile.read(reinterpret_cast<char*>(&newRecord.numCustomers), sizeof(newRecord.numCustomers));
        reservations.push_back(newRecord); 
    }
}

Date compCurrentDate()
{
   Date currentDate;
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
   currentDate.hour = structuredTime.tm_hour;

   return currentDate;
}

bool lessEqual( const Date &date1, const Date &date2 )
{
    if (date1.year < date2.year)
        return true;
    else if (date1.year > date2.year)
        return false;
    else
    {
        if (date1.month < date2.month)
            return true;
        else if(date1.month > date2.month)
        {
            return false;
        }
        else
        {
            if (date1.day < date2.day)
                return true;
            else if (date1.day > date2.day)
                return false;
            else
            {
                if (date1.hour <= date2.hour)
                    return true;
                else
                    return false;
            }
        }
    }

}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );
   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void login( const vector< MemberRecord > &memberDetails,
            vector< ReservationRecord > &reservations )
{
   char idNumber[ 12 ] = "";
   char password[ 24 ] = "";

   do {
      cout << "Please enter your ID number: ";
      cin >> idNumber;
      cout << "Enter your password: ";
      cin >> password;
   } while( !valid( idNumber, password, memberDetails ) );

   cin.ignore();

   int choice;

   while( true )
   {      
      cout << "\n1 - Make Reservation\n";
      cout << "2 - Reservation Enquiry/Canceling\n";
      cout << "3 - End\n";

      do cout << "\nEnter your choice (1~3): ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch ( choice )
      {
      case 1:
         reservation( idNumber, reservations );
         break;

      case 2:
         queryDelete( idNumber, reservations );
         break;

      case 3:
         return;

      default:
         cout << "\nIncorrect choice!\n";
         break;
      }
   }
}

bool valid( char idNumber[], char password[], const vector< MemberRecord > &memberDetails )
{
    bool is_valid = false;
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (i == memberDetails.size() - 1)
        {
            if (memberDetails[i].idNumber != idNumber)
            {
                is_valid = true;
                break;
            }
            else
            {
                if (memberDetails[i].password != password)
                {
                    is_valid = true;
                    break;
                }
                else
                    is_valid = false;
            }
        }

        if (memberDetails[i].idNumber != idNumber)
        {
            continue;
        }
        else
        {
            if (memberDetails[i].password != password)
            {
                continue;
            }
            else
            {
                is_valid = false;
                break;
            }
        } 
    }

    if(is_valid==false)
        cout << "Invalid account number or password. Please try again." << endl;
    return is_valid;
}

void reservation( char idNumber[], vector< ReservationRecord > &reservations )
{
   ReservationRecord newReservation={};
   newReservation.idNumber = idNumber;
   for (int i = 1; i <= 18; i++)
   {
       cout << i << "." << branchNames[i] << endl;
   }
   cout << endl;
   int n1 = 0;
   
   do
   {
       cout << "Enter your choice (0 to end):";
       cin >> n1;
   } while (n1 > 18 || n1 < 0);
   cout << endl;

   Date currentDate = compCurrentDate();
   
   cout << "The current hour is " << currentDate.year << "/" << currentDate.month << "/" << currentDate.day << ":" << currentDate.hour << endl;

   cout << "Available days:" << endl;
   Date availableDates[7];
   compAvailableDates(availableDates);
   for (int i = 0; i < 7; i++)
   {
       cout << endl;
       cout << i + 1 << ". " << availableDates[i].year << "/" << availableDates[i].month << "/" << availableDates[i].day << ":" << availableDates[i].hour << endl;
   }

   int n2;
   do
   {
       cout << "Enter your choice (0 to end):";
       cin >> n2;
       cout << endl;
   } while (n2 > 7 || n2 < 0);

   int selected_hour;
   int min_hour = 0;
   int max_hour = 23;
   do
   {
       if (availableDates[n2 - 1].year == currentDate.year && availableDates[n2 - 1].month == currentDate.month
           && availableDates[n2 - 1].day == currentDate.day)
       {
           if (currentDate.hour >= min_hour)
           {
               min_hour = currentDate.hour + 1;
           }
       }
       cout << "Enter hour (" << min_hour << " ~ " << max_hour << "):";
       cin >> selected_hour;
       cout << endl;
   } while (selected_hour > max_hour || selected_hour < min_hour);

   do
   {
       cout << "Enter the number of customers (1~30, 0 to end):";
       cin >> newReservation.numCustomers;
       cout << endl;
   } while (newReservation.numCustomers < 0 || newReservation.numCustomers>30);

   newReservation.idNumber=

   cout << endl << setw( 26 ) << "Branch"
                << setw( 14 ) << "Date" << setw( 8 ) << "Hour"
                << setw( 19 ) << "No of Customers" << endl;

   output( newReservation );

   cout << "\nReservation Completed!\n";

   reservations.push_back( newReservation );
}

void compAvailableDates( Date availableDates[] )
{
    Date currentDate = compCurrentDate();
    int i = 0;
    bool is_even = false;
    if ((currentDate.year % 400 == 0) || (currentDate.year % 4 == 0 && currentDate.year % 100 != 0))
        is_even = true;
    
    while (i < 7)
    {
        if (i == 0)
        {
            if (currentDate.hour < 23)
            {
                availableDates[i] = currentDate; 
            }
            else
            {
                availableDates[i] = currentDate;
                availableDates[i].day++;
                if (availableDates[i].month == 2)
                {
                    if (is_even != true && availableDates[i].day == 29)
                    {
                        availableDates[i].month++;
                        availableDates[i].day = 1;
                    }
                    else if ((is_even == true && availableDates[i].day == 30))
                    {
                        availableDates[i].month++;
                        availableDates[i].day = 1;
                    }
                }
                if (availableDates[i].day == 31 && (availableDates[i].month == 4 || availableDates[i].month == 6 ||
                    availableDates[i].month == 9 || availableDates[i].month == 11))
                {
                    availableDates[i].month++;
                    availableDates[i].day = 1;
                }
                if (availableDates[i].day == 32 && (availableDates[i].month == 1 || availableDates[i].month == 3 ||
                    availableDates[i].month == 5 || availableDates[i].month == 7 || availableDates[i].month == 8
                    || availableDates[i].month == 10 || availableDates[i].month == 12))
                {
                    if (availableDates[i].month == 12)
                    {
                        availableDates[i].year++;
                        availableDates[i].month = 1;
                        availableDates[i].day = 1;
                    }
                    else
                    {
                        availableDates[i].month++;
                        availableDates[i].day = 1;
                    }  
                }
            }
            i++;
            continue;
        }
        availableDates[i].day = availableDates[i - 1].day + 1;
        if (availableDates[i].month == 2)
        {
            if (is_even != true && availableDates[i].day == 29)
            {
                availableDates[i].month++;
                availableDates[i].day = 1;
            }
            else if ((is_even == true && availableDates[i].day == 30))
            {
                availableDates[i].month++;
                availableDates[i].day = 1;
            }
        }
        if (availableDates[i].day == 31 && (availableDates[i].month == 4 || availableDates[i].month == 6 ||
            availableDates[i].month == 9 || availableDates[i].month == 11))
        {
            availableDates[i].month++;
            availableDates[i].day = 1;
        }
        if (availableDates[i].day == 32 && (availableDates[i].month == 1 || availableDates[i].month == 3 ||
            availableDates[i].month == 5 || availableDates[i].month == 7 || availableDates[i].month == 8
            || availableDates[i].month == 10 || availableDates[i].month == 12))
        {
            if (availableDates[i].month == 12)
            {
                availableDates[i].year++;
                availableDates[i].month = 1;
                availableDates[i].day = 1;
            }
            else
            {
                availableDates[i].month++;
                availableDates[i].day = 1;
            }
        }
        i++;
    }
    return;
}

void output( ReservationRecord reservation )
{
   cout << setw( 26 ) << branchNames[ reservation.branchCode ]
        << setw( 8 ) << reservation.date.year << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.month << '-'
        << setw( 2 ) << setfill( '0' ) << reservation.date.day
        << setw( 8 ) << setfill( ' ' ) << reservation.date.hour
        << setw( 19 ) << reservation.numCustomers << endl;
}

void queryDelete( char idNumber[], vector< ReservationRecord > &reservations )
{
   Date currentDate = compCurrentDate();



}

void registration( vector< MemberRecord > &memberDetails )
{
   MemberRecord newMember;

   cout << "Input your ID Number: ";
   cin >> newMember.idNumber;
   cin.ignore();

   if( existingID( newMember.idNumber, memberDetails ) )
   {
      cout << "\nYou are already a member!\n\n";
      return;
   }

   cout << "Input your Name: ";
   cin >> newMember.name;

   cout << "Choose a password: ";
   cin >> newMember.password;

   cin.ignore();

   memberDetails.push_back( newMember );

   cout << "\nRegistration Completed!\n\n";
}

bool existingID( char idNumber[], const vector< MemberRecord > &memberDetails )
{
    for (int i = 0; i < memberDetails.size(); i++)
    {
        if (memberDetails[i].idNumber != idNumber)
            continue;
        else
            return true;

        if (i == memberDetails.size() - 1)
        {
            if (memberDetails[i].idNumber != idNumber)
                return true;
            else
                return false;
        }
    }
    return false;
}

void saveMemberDetails( const vector< MemberRecord > &memberDetails )
{
    ofstream outfile("Members.dat", ios::binary);
    outfile.seekp(ios::end);
    for (int i = 0; i < memberDetails.size(); i++)
    {
        outfile.write(memberDetails[i].idNumber, sizeof(memberDetails[i].idNumber));
        outfile.write(memberDetails[i].password, sizeof(memberDetails[i].password));
        outfile.write(memberDetails[i].name, sizeof(memberDetails[i].name));
    }
    return;
}

void saveReservations( const vector< ReservationRecord > &reservations )
{
    ofstream outfile("Reservations.dat", ios::binary);
    outfile.seekp(ios::end);
    for (int i = 0; i < reservations.size(); i++)
    {
        outfile.write(reservations[i].idNumber, sizeof(reservations[i].idNumber));
        outfile.write(reinterpret_cast<const char*>(&reservations[i].branchCode), sizeof(reservations[i].branchCode));
        outfile.write(reinterpret_cast<const char*>(&reservations[i].date), sizeof(reservations[i].date));
        outfile.write(reinterpret_cast<const char*>(&reservations[i].numCustomers), sizeof(reservations[i].numCustomers));
    }
    return;
}