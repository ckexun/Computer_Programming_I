#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <fstream>
using std::ifstream;
using std::ofstream;
using std::ios;

#include <vector>
using std::vector;

struct Date
{
    int year;
    int month;
    int day;
    int hour;
};

struct MemberRecord
{
    char idNumber[12];   // account number
    char password[24];   // password
    char name[8];        // name
};

struct ReservationRecord
{
    char idNumber[12]; // account number
    int branchCode;      // branch code
    Date date;           // reservation date
    int numCustomers;    // number of customers
};

char branchNames[19][24] = { "", "Taipei Dunhua South",   "Taipei Zhongxiao",
                                     "Taipei Songjiang",    "Taipei Nanjing",
                                     "Taipei Linsen",       "Taipei Zhonghua New",
                                     "Banqiao Guanqian",    "Yonghe Lehua",
                                     "Taoyuan Zhonghua",    "Taoyuan Nankan",
                                     "Zhongli Zhongyang",   "Hsinchu Beida",
                                     "Taichung Ziyou",      "Chiayi Ren'ai",
                                     "Tainan Ximen",        "Kaohsiung Zhonghua New",
                                     "Kaohsiung Jianxing",  "Pingtung Kending" };

// read all memberDetails from the file Members.dat
void loadMemberDetails(vector< MemberRecord >& memberDetails);

// read all reservations that are not out of date, from the file Reservations.dat
void loadReservations(vector< ReservationRecord >& reservations);

// compute the current date
Date compCurrentDate();

// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2);

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

// login and display the submenu
void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations);

// there exists a member with specified idNumber and password
bool valid(char idNumber[], char password[],
    const vector< MemberRecord >& memberDetails);

// add a new reservation for the member with specified IDnumber
void reservation(char idNumber[], vector< ReservationRecord >& reservations);

// compute 7 dates which is starting from the current date
void compAvailableDates(Date availableDates[]);

// display all fields of reservation
void output(ReservationRecord reservation);

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations);

// add a new member
void registration(vector< MemberRecord >& memberDetails);

// return true if idNumber is a legal ID number
//bool legalID( char idNumber[] );

// return true if idNumber belongs to memberDetails
bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails);

// write all memberDetails into the file Members.dat
void saveMemberDetails(const vector< MemberRecord >& memberDetails);

// write all reservations that are not out of date, into the file Reservations.dat
void saveReservations(const vector< ReservationRecord >& reservations);

int main()
{
    vector< MemberRecord > memberDetails; // member details for all members
    vector< ReservationRecord > reservations; // all reservations

    loadMemberDetails(memberDetails);
    loadReservations(reservations);

    cout << "Welcome to the Cashbox Party World!\n\n";

    int choice;
    while (true)
    {
        cout << "1 - Login\n";
        cout << "2 - Registration\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            login(memberDetails, reservations);
            break;

        case 2:
            registration(memberDetails);
            break;

        case 3:
            saveMemberDetails(memberDetails);
            saveReservations(reservations);
            cout << "Thank you! Goodbye!\n\n";
            system("pause");
            return 0;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }

    system("pause");
}

void loadMemberDetails(vector< MemberRecord >& memberDetails)
{
    ifstream file("Members.dat", ios::in | ios::binary);
    if (!file)
        cout << "1.fail";
    file.seekg(0, ios::end);
    int num = static_cast<int>(file.tellg()) / sizeof(MemberRecord);
    file.seekg(0, ios::beg);

    MemberRecord temp[90]{};
    for (int i = 1; i <= 90; i++) {
        file.read(reinterpret_cast<char*>(&temp[i]), sizeof(MemberRecord));
        memberDetails.push_back(temp[i]);
    }


    //cout << endl << "pp" << endl << memberDetails[1].idNumber;
    file.close();
}

void loadReservations(vector< ReservationRecord >& reservations)
{
    ifstream file("Reservations.dat", ios::in | ios::binary);
    if (!file)
        cout << "2.fail";
    file.seekg(0, ios::end);
    int num = static_cast<int>(file.tellg()) / sizeof(ReservationRecord);
    file.seekg(0, ios::beg);

    ReservationRecord temp[90]{};
    for (int i = 1; i <= 90; i++) {
        file.read(reinterpret_cast<char*>(&temp[i]), sizeof(ReservationRecord));
        reservations.push_back(temp[i]);
    }


    file.close();
}

Date compCurrentDate()
{
    Date currentDate;
    tm structuredTime;
    time_t rawTime = time(0);           //�j��    time_t rawTime = time(0)+24*60*60;
    localtime_s(&structuredTime, &rawTime);

    currentDate.year = structuredTime.tm_year + 1900;
    currentDate.month = structuredTime.tm_mon + 1;
    currentDate.day = structuredTime.tm_mday;
    currentDate.hour = structuredTime.tm_hour;

    return currentDate;
}
// return true if and only if date1 <= date2
bool lessEqual(const Date& date1, const Date& date2)
{
    if (date1.year < date2.year)
        return true;
    else if (date1.year > date2.year)
        return false;
    else {
        if (date1.month < date2.month)
            return true;
        else if (date1.month > date2.month)
            return false;
        else {
            if (date1.day <= date2.day)
                return true;
            else
                return false;
        }
    }
}

int inputAnInteger(int begin, int end)            //teacher
{
    char string[80];
    cin.getline(string, 80, '\n');

    if (strlen(string) == 0)
        exit(0);

    for (unsigned int i = 0; i < strlen(string); i++)
        if (string[i] < '0' || string[i] > '9')
            return -1;

    int number = atoi(string);
    if (number >= begin && number <= end)
        return number;
    else
        return -1;
}

void login(const vector< MemberRecord >& memberDetails,
    vector< ReservationRecord >& reservations)
{
    char idNumber[12] = "";
    char password[24] = "";

    do {
        cout << "Please enter your ID number: ";
        cin >> idNumber;
        cout << "Enter your password: ";
        cin >> password;
    } while (0);

    cin.ignore();

    int choice;

    while (true)
    {
        cout << "\n1 - Make Reservation\n";
        cout << "2 - Reservation Enquiry/Canceling\n";
        cout << "3 - End\n";

        do cout << "\nEnter your choice (1~3): ";
        while ((choice = inputAnInteger(1, 3)) == -1);
        cout << endl;

        switch (choice)
        {
        case 1:
            reservation(idNumber, reservations);
            break;

        case 2:
            queryDelete(idNumber, reservations);
            break;

        case 3:
            return;

        default:
            cout << "\nIncorrect choice!\n";
            break;
        }
    }
}
// there exists a member with specified idNumber and password

bool valid(char idNumber[], char password[], const vector< MemberRecord >& memberDetails)     //�n��i <= 200
{
    //cout << endl << endl << endl << "pppp" << endl << endl << endl << endl;
    bool boo = true;
    for (int i = 1; i <= 5; i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0 && strcmp(password, memberDetails[i].password) == 0) {
            boo = false;

        }
    }
    if (boo == true) {
        cout << endl;
        cout << "Invalid account number or password. Please try again."<<endl;
        cout << endl;
        return false;
    }
    else {
        return true;
    }

}

void reservation(char idNumber[], vector< ReservationRecord >& reservations)                //teacher
{
    ReservationRecord newReservation;

    for (int i = 1; i < 19; i++) {
        cout << i << ". " << branchNames[i] << endl;
    }
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> newReservation.branchCode;
        cout << endl;
    } while (newReservation.branchCode < 0 || newReservation.branchCode>18);

    if (newReservation.branchCode == 0)
        return;

    Date current = compCurrentDate();
    cout << endl << "The current hour is " << current.year << '/' << current.month << '/' << current.day << ':' << current.hour;
    cout << endl << endl << "Available days:" << endl << endl;

    Date available[10]{};
    compAvailableDates(available);

    int choice = 0;
    bool boo = true;
    do {
        cout << endl << "Enter your choice (0 to end): ";
        cin >> choice;
cout << endl;
    } while (choice < 0 || choice>7);

    if (choice == 0)
        return;

    int choosey = available[choice].year;
    int choosem = available[choice].month;
    int choosed = available[choice].day;
    int chooseh = 0;

    do {
        cout << endl << "Enter hour (" << current.hour + 1 << "~23): ";
        cin >> chooseh;
        cout << endl;
    } while (chooseh < current.hour + 1 || chooseh>23);

    do {
        cout << endl << "Enter the number of customers (1~30, 0 to end): ";
        cin >> newReservation.numCustomers;
        cout << endl;
    } while (newReservation.numCustomers < 0 || newReservation.numCustomers>30);

    newReservation.date = { choosey,choosem,choosed,chooseh };


    cout << endl << setw(26) << "Branch"
        << setw(14) << "Date" << setw(8) << "Hour"
        << setw(19) << "No of Customers" << endl;

    output(newReservation);

    cout << "\nReservation Completed!\n";

    reservations.push_back(newReservation);
}

// compute 7 dates which is starting from the current date

void compAvailableDates(Date availableDates[])
{
    Date currentDate = compCurrentDate();

    int tempy = currentDate.year;
    int tempm = currentDate.month;
    int tempd = currentDate.day;
    if (currentDate.hour == 23)
        tempd++;
    for (int i = 1; i < 8; i++) {
        if ((tempm == 1 || tempm == 3 || tempm == 5 || tempm == 7 || tempm == 8 || tempm == 10 || tempm == 12) && tempd > 31) {
            tempm += 1;
            tempd -= 31;
            if (tempm > 12) {
                tempy += 1;
                tempm -= 12;
            }
        }
        else if (tempm == 2) {
            int t = tempy - 2024;
            t %= 4;
            if (t == 0) {
                if (tempd > 29) {
                    tempm += 1;
                    tempd -= 29;
                }
                else {
                    tempm += 1;
                    tempd -= 28;
                }
            }
        }
        else {
            if (tempd > 30) {
                tempm += 1;
                tempd -= 30;
            }
        }
        cout << i << ". " << tempy << '/' << tempm << '/' << tempd - 1 + i << endl;
        availableDates[i] = { tempy,tempm,tempd - 1 + i };
    }


}

void output(ReservationRecord reservation)                                //teacher
{
    cout << setw(26) << branchNames[reservation.branchCode]
        << setw(8) << reservation.date.year << '-'
        << setw(2) << setfill('0') << reservation.date.month << '-'
        << setw(2) << setfill('0') << reservation.date.day
        << setw(8) << setfill(' ') << reservation.date.hour
        << setw(19) << reservation.numCustomers << endl;
}

// display all reservations for the member with specified IDnumber,
// then let the member to choose one of them to delete
void queryDelete(char idNumber[], vector< ReservationRecord >& reservations)
{
    
    Date currentDate = compCurrentDate();

    int count = 1;
    int temp[20]{};
    for (int i = 0; i < 50; i++) {
        if (strcmp(idNumber, reservations[i].idNumber) == 0&& lessEqual(currentDate, reservations[i].date) == true) {
                cout << count << ". ";
                output(reservations[i]);
                temp[count] = i;
                count++;
        }
    }
    int choice = 0;
    do {
        cout << "Choose a reservation to cancel (0: keep all reservations): ";
        cin >> choice;
    } while (choice<0 || choice>count);
    if (choice == 0)
        return;
    
    reservations.erase(reservations.begin() + temp[choice], reservations.begin() + 1 + temp[choice]);
}

void registration(vector< MemberRecord >& memberDetails)
{
    MemberRecord newMember;

    cout << "Input your ID Number: ";
    cin >> newMember.idNumber;
    cin.ignore();

    if (existingID(newMember.idNumber, memberDetails))
    {
        cout << "\nYou are already a member!\n\n";
        return;
    }

    cout << "Input your Name: ";
    cin >> newMember.name;

    cout << "Choose a password: ";
    cin >> newMember.password;

    cin.ignore();

    memberDetails.push_back(newMember);

    cout << "\nRegistration Completed!\n\n";
}

// return true if idNumber belongs to memberDetails

bool existingID(char idNumber[], const vector< MemberRecord >& memberDetails)
{
    for (int i =0; i <= 10; i++) {
        if (strcmp(idNumber, memberDetails[i].idNumber) == 0) {
            return true;
        }
    }
    return false;
}

void saveMemberDetails(const vector< MemberRecord >& memberDetails)
{
    ofstream file("Members.dat", ios::app | ios::binary);

    for (int i = 0; i <= 10; i++) {
        file.write(reinterpret_cast<const char*>(&memberDetails[i]), sizeof(MemberRecord));
    }
    file.close();
}

void saveReservations(const vector< ReservationRecord >& reservations)
{
    ofstream file("Reservations.dat", ios::app | ios::binary);

    for (int i = 0; i <= 10; i++) {
        file.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(ReservationRecord));
    }
    file.close();
}
//    cout << endl << endl << "debug" << endl << endl;
