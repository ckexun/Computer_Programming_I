﻿// Compute the square root of a huge integer.
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <cstring>
#include <cmath>

//甚麼是size_t = int ，但是cout的部分"digits[" << i << "] = " 會錯
//為什麼有的是size_t，有的是int   ???
struct HugeInt
{
    size_t size = 0;
    int* integer = nullptr;
};

// put the square root of hugeInt into the array squareRoot
void compSquareRoot(HugeInt& hugeInt, HugeInt& squareRoot);

// put the square of hugeInt into the array square
void compSquare(HugeInt& hugeInt, HugeInt& square);

// if hugeInt1 == hugeInt2, return true; otherwise, return false
bool equal(HugeInt& hugeInt1, HugeInt& hugeInt2);

// if hugeInt1 < hugeInt2, return true; otherwise, return false
bool less(HugeInt& hugeInt1, HugeInt& hugeInt2);

int main()
{
    int testCase;
    cin >> testCase;
    for (int i = 1; i <= testCase; i++)
    {
        char str[1010] = {};
        cin >> str;

        //小於十位數字就用數學函式
        //直接變成位數
        size_t numDigits = strlen(str);

        if (numDigits < 10)
            cout << sqrt(atoi(str)) << endl;
        else
        {
            //將字串轉成數字
            //並且把頭到尾位置交換
            int* digits = new int[numDigits + 2]();
            for (size_t j = 0; j < numDigits; ++j)
            {
                digits[j] = str[numDigits - 1 - j] - '0';
                //cout << digits[j] << endl;
            }

            //cout << "digits" << numDigits << endl;

            //for (int i = numDigits - 1; i >= 0; i--)
            //    cout << "digits[" << i << "] = " << digits[i] << endl;
            //numDigits = 13
            //last = 4
            //size = 5
            size_t last = (numDigits - 1) / 3;
            HugeInt hugeInt;
            hugeInt.size = last + 1;
            hugeInt.integer = new int[hugeInt.size]();
            for (size_t j = 0; j <= last; j++)
            {
                hugeInt.integer[j] = digits[3 * j] + digits[3 * j + 1] * 10 + digits[3 * j + 2] * 100;
                //cout << "[" <<j << "]= " << hugeInt.integer[j] << endl;
            }

            //squareRoot.size = 3
            HugeInt squareRoot; // the square root of hugeInt
            squareRoot.size = (hugeInt.size + 1) / 2; // the number of digits of squareRoot
            squareRoot.integer = new int[squareRoot.size](); // the square root of hugeInt

            // put the square root of hugeInt into the array squareRoot
            compSquareRoot(hugeInt, squareRoot);

            cout << squareRoot.integer[squareRoot.size - 1];
            for (int j = squareRoot.size - 2; j >= 0; j--)
                cout << setw(3) << setfill('0') << squareRoot.integer[j];
            cout << endl;

            delete[] squareRoot.integer;
            delete[] hugeInt.integer;
            delete[] digits;
        }

        if (i < testCase)
            cout << endl;
    }

    //   system( "pause" );
}

//7206604678144
// 569340939211471389962659798742921403066676585830944139425416207103163630830729373807431127122499903016459194716196
// 754546843616399597461910880324043468889050588209687659514
// 6922779789710140382458715982951055336079400474699183892516894930254222851053938842387613077129022047602130232052869523857646085908323733033595475017186265049422736320110783517478924300608134865834175487347257298433853747871153794802075704105491897179487752542251328640472000730058247543290247261123286581978052693810252060450834424262483797929175732402696094562577375928836425965799878980229923886468643414529681012438713608362940467459692740845977496433830532747394677291364443983202079264967275590748924154757772559945728896499330987730566442827849067786616255908197866122503713331041857956843501080228659615692539211254299161081331734230936917509501122996493832084592823213695439523323284373400860460417142936746289651301445122361001913095771390497955327531910919515811170786925051192115168523299950497978917856662683406534319769922537144778707800230254451857038449249747792778529140155546480846847948074532208400
//83203243865309364406014918518317473130446708465890844211360851041072066452208962301556563794545130605254295091957973490454063962186483518098680884374995909691276966170925490734928691122229854808263487229063340592267617369429375700154206829192737145710320947059567871411568646793807243517729774258834559963533251192576649423611921859339712914207909323006925767162317933162890085688671333315121524430224360043880388666070175027948372237880633353215307138264220
// put the square root of hugeInt into the array squareRoot
void compSquareRoot(HugeInt& hugeInt, HugeInt& squareRoot)
{
    /*
    squareRoot.size = (hugeInt.size + 1) / 2; // the number of digits of squareRoot
    squareRoot.integer = new int[squareRoot.size](); // the square root of hugeInt
    */
    //一個size+array
    //size = 3
    HugeInt big;
    big.size = hugeInt.size;
    big.integer = new int[big.size]();

    for (int k = squareRoot.size - 1 ; k >= 0  ; k--)
    {
        size_t low = 0;
        size_t high = 999;
        size_t middle;

        while (low <= high)
        {
            //cout << "k = " << k << endl;

            for (size_t i = 0; i < big.size; i++)
                big.integer[i] = 0;

            middle = (low + high) / 2;

            //cout << middle << endl;

            //middle = 499
            // size = 2
            squareRoot.integer[k] = middle;

            //for (size_t i = 0; i < squareRoot.size; i++)
            //    cout << "squareRoot.integer[" << i << "]= " << squareRoot.integer[i] << endl;

            //squareRoot平方去做比較
            //compSquare(HugeInt & hugeInt, HugeInt & square)
            compSquare(big, squareRoot);

            //for (size_t i = 0; i < big.size; i++)
            //    cout << "big.integer[" << i << "]= " << big.integer[i] << endl;
            
            //問題是要把499丟到陣列裡面去

            //for (size_t j = 0; j <= last; j++)
            //{
            //    hugeInt.integer[j] = digits[3 * j] + digits[3 * j + 1] * 10 + digits[3 * j + 2] * 100;
            //    //cout << hugeInt.integer[j] << endl;
            //}

            //問題是要怎麼回傳
            //number == data[ middle ] 
            if (equal(hugeInt, big))
                return;

            //number < data[ middle ]
            if (less(hugeInt, big))
            {
                high = squareRoot.integer[k] - 1;
                //cout << "high= " << high << endl;
            }
            else if (less(big, hugeInt))        //number > data[ middle ] 
            {
                low = squareRoot.integer[k] + 1;
                //cout << "low= " << low << endl;
            }
        }

        if (less(hugeInt, big))
            squareRoot.integer[k]--;
    }
    return;
    delete[] big.integer;
}

//7206604678144
// put the square of hugeInt into the array square
void compSquare(HugeInt& hugeInt, HugeInt& square)
{

    //for (size_t i = 0; i < hugeInt.size; i++)
    //{
    //    cout << hugeInt.integer[i] << endl;
    //}

    //cout << "機掰" << endl;

 /*   for (size_t i = 0; i < square.size; i++)
    {
        cout << square.integer[i] << endl;
    }

    cout << "靠杯" << endl;*/

    //cout << square.size << endl;

    for (size_t i = 0; i < square.size; i++)
    {
        for (size_t j = 0; j < square.size; j++)
        {
            hugeInt.integer[i + j] += square.integer[i] * square.integer[j];
        }
    }

    //cout << hugeInt.size << endl;

    //for (size_t i = 0; i < hugeInt.size; i++)
    //{
    //    cout << hugeInt.integer[i] << endl;
    //}

    //cout << "幹你娘機掰" << endl;

    int temp1 = 0;
    int temp2 = 0;
    //每大於999就進位
    for (size_t i = 0; i < hugeInt.size - 1 ; i++)
    {
        if (hugeInt.integer[i] > 999)
        {
            temp1 = hugeInt.integer[i];
            hugeInt.integer[i] = hugeInt.integer[i] % 1000;
            //cout << "hugeInt.integer= " << hugeInt.integer[i] << endl;

            temp2 = temp1 / 1000;
            //cout << "temp2= " << temp2 << endl;

            hugeInt.integer[i + 1] += temp2;
        }
    }

    //for (size_t i = 0; i < hugeInt.size - 1; i++)
    //{
    //    hugeInt.integer[i]
    //}

    //for (size_t i = 0; i < hugeInt.size; i++)
    //{
    //    cout << hugeInt.integer[i] << endl;
    //}

    //cout << "你好" << endl;
}

// if hugeInt1 == hugeInt2, return true; otherwise, return false
bool equal(HugeInt& hugeInt1, HugeInt& hugeInt2)
{
    if (hugeInt1.size != hugeInt2.size)
        return false;

    for (int i = hugeInt1.size - 1; i >= 0; i--)
        if (hugeInt1.integer[i] != hugeInt2.integer[i])
            return false;

    return true;
}

// if hugeInt1 < hugeInt2, retuen true; otherwise, return false
bool less(HugeInt& hugeInt1, HugeInt& hugeInt2)
{
    if (hugeInt1.size < hugeInt2.size)
    {
        return true;
    }
    else if (hugeInt1.size == hugeInt2.size)
    {
        for (int i = hugeInt1.size - 1; i >= 0; i--)
        {
            if (hugeInt1.integer[i] > hugeInt2.integer[i])
                return false;
            else if (hugeInt1.integer[i] < hugeInt2.integer[i])
                return true;
            //else if (hugeInt1.integer[i] = hugeInt2.integer[i])
            //    return false;
        }
    }
    else if (hugeInt1.size > hugeInt2.size)
    {
        return false;
    }


}

//int main()
//{
//    char str[1010] = {};
//    cin >> str;
//
//    size_t numDigits = strlen(str);
//
//    int* digits = new int[numDigits + 2]();
//    for (size_t j = 0; j < numDigits; ++j)
//        digits[j] = str[numDigits - 1 - j] - '0';
//
//    size_t last = (numDigits - 1) / 3;
//    HugeInt hugeInt;
//    hugeInt.size = last + 1;
//    hugeInt.integer = new int[hugeInt.size]();
//    for (size_t j = 0; j <= last; j++)
//        hugeInt.integer[j] = digits[3 * j] + digits[3 * j + 1] * 10 + digits[3 * j + 2] * 100;
//
//    ////squareRoot.size = 3
//    //HugeInt squareRoot; // the square root of hugeInt
//    //squareRoot.size = (hugeInt.size + 1) / 2; // the number of digits of squareRoot
//    //squareRoot.integer = new int[squareRoot.size](); // the square root of hugeInt
//
//    //cout << squareRoot.size << endl;
//
//    //cout << hugeInt.size << endl;
//
//    HugeInt big;
//    big.size = hugeInt.size * 2 - 1;
//    big.integer = new int[big.size]();
//
//    //cout << big.size << endl;
//
//    compSquare(big, hugeInt);
//    for (int i = big.size - 1; i >= 0; i--)
//    {
//        cout << big.integer[i] << endl;
//    }
//
//}