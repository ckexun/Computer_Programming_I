// Compute the square root of a huge integer.
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

#include <iomanip>
using std::setw;
using std::setfill;

#include <cstring>
#include <cmath>

struct HugeInt
{
   size_t size = 0;
   int *integer = nullptr;
};

// put the square root of hugeInt into the array squareRoot
void compSquareRoot( HugeInt &hugeInt, HugeInt &squareRoot );

// put the square of hugeInt into the array square
void compSquare( HugeInt &hugeInt, HugeInt &square );

// if hugeInt1 == hugeInt2, return true; otherwise, return false
bool equal( HugeInt &hugeInt1, HugeInt &hugeInt2 );

// if hugeInt1 < hugeInt2, return true; otherwise, return false
bool less( HugeInt &hugeInt1, HugeInt &hugeInt2 );

int main()
{
   int testCase;
   cin >> testCase;
   for( int i = 1; i <= testCase; i++ )
   {
      char str[ 1010 ] = {};
      cin >> str;

      size_t numDigits = strlen( str );
      
      if( numDigits < 10 )
         cout << sqrt( atoi( str ) ) << endl;
      else
      {
         int *digits = new int[ numDigits + 2 ]();
         for( size_t j = 0; j < numDigits; ++j )
            digits[ j ] = str[ numDigits - 1 - j ] - '0';

         size_t last = ( numDigits - 1 ) / 3;
         HugeInt hugeInt;
         hugeInt.size = last + 1;
         hugeInt.integer = new int[ hugeInt.size ]();
         for( size_t j = 0; j <= last; j++ )
            hugeInt.integer[ j ] = digits[ 3 * j ] + digits[ 3 * j + 1 ] * 10 + digits[ 3 * j + 2 ] * 100;

         HugeInt squareRoot; // the square root of hugeInt
         squareRoot.size = ( hugeInt.size + 1 ) / 2; // the number of digits of squareRoot
         squareRoot.integer = new int[ squareRoot.size ](); // the square root of hugeInt
         
         // put the square root of hugeInt into the array squareRoot
         compSquareRoot( hugeInt, squareRoot );
         
         cout << squareRoot.integer[ squareRoot.size - 1 ];
         for( int j = squareRoot.size - 2; j >= 0; j-- )
            cout << setw( 3 ) << setfill( '0' ) << squareRoot.integer[ j ];
         cout << endl;
      
         delete[] squareRoot.integer;
         delete[] hugeInt.integer;
         delete[] digits;
      }

      if( i < testCase )
         cout << endl;
   }

//   system( "pause" );
}

// put the square root of hugeInt into the array squareRoot
void compSquareRoot( HugeInt &hugeInt, HugeInt &squareRoot )
{
    
    int low = 0;
    int high = 999;
    int middle = 0;
    int number = 0;
    int b;
    if (hugeInt.size % 2 == 0) {
        while (low <= high)
        {
            middle = (low + high) / 2;
            number = hugeInt.integer[hugeInt.size - 1] * 1000 + hugeInt.integer[hugeInt.size - 2];
            if (middle * middle == number)
                squareRoot.integer[squareRoot.size - 1] = middle;
            if (number < middle * middle)
                high = middle - 1;
            else
                low = middle + 1;

        }
        if (number <middle * middle)middle--;
        squareRoot.integer[squareRoot.size - 1] = middle;
        
    }
    else if (hugeInt.size % 2 != 0) {
        while (low <= high)
        {
            middle = (low + high) / 2;
            if (middle * middle == hugeInt.integer[hugeInt.size - 1])
                squareRoot.integer[squareRoot.size - 1] = middle;
            if (hugeInt.integer[hugeInt.size - 1] < middle * middle)
                high = middle - 1;
            else
                low = middle + 1;

        }
        if (hugeInt.integer[hugeInt.size - 1]< middle * middle)middle--;
        squareRoot.integer[squareRoot.size - 1] = middle ;
       
    }
   
    for (int a = squareRoot.size-2; a >= 0; a--) 
    {
        HugeInt square;
        square.size = hugeInt.size;
        int low = 0;
        int high = 999;
        int middle = 0;
        while (low <= high)
        {
            
            square.integer = new int[square.size]();
            middle = (low + high) / 2;
            squareRoot.integer[a] = middle;
            compSquare(squareRoot, square);
            
            
            if (less(hugeInt,square))
                high = middle - 1;
            else 
                low = middle + 1;
            delete[]square.integer;
        }
        
        square.integer = new int[square.size]();
        compSquare(squareRoot, square);
        if (less(hugeInt, square))middle--;
        delete[]square.integer;
      
        squareRoot.integer[a] = middle ;
       
    } 
  
}

// put the square of hugeInt into the array square
void compSquare( HugeInt &hugeInt, HugeInt &square )
{
   
   
    for (int a = 0; a < hugeInt.size; a++) {
        for (int b = 0; b < hugeInt.size; b++) {
            square.integer[a + b] = hugeInt.integer[a] * hugeInt.integer[b] + square.integer[a + b];
        }
    }
    
    for (int c = 0; c < square.size; c++) {
        if (square.integer[c] >= 1000) {
            int num = square.integer[c] / 1000;
            square.integer[c] %= 1000;
            square.integer[c + 1] += num;
            
        }
    }
    while (square.integer[square.size - 1] == 0)square.size--;
   


}

// if hugeInt1 == hugeInt2, return true; otherwise, return false
bool equal( HugeInt &hugeInt1, HugeInt &hugeInt2 )
{
   if( hugeInt1.size != hugeInt2.size )
      return false;

   for( int i = hugeInt1.size - 1; i >= 0; i-- )
      if( hugeInt1.integer[ i ] != hugeInt2.integer[ i ] )
         return false;

   return true;
}

// if hugeInt1 < hugeInt2, retuen true; otherwise, return false
bool less( HugeInt &hugeInt1, HugeInt &hugeInt2 )
{
    if (hugeInt1.size < hugeInt2.size)return true;
    if (hugeInt1.size == hugeInt2.size)
    {
        for (int a = hugeInt1.size - 1; a >= 0; a--)
        {
            if (hugeInt1.integer[a] < hugeInt2.integer[a])return true;
            if (hugeInt1.integer[a] > hugeInt2.integer[a])return false;
        }
    }
    return false;

}